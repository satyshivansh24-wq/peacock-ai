# Vercel Serverless Function Entry Point for PEACOCK AI
import os
import sys

current_dir = os.path.dirname(os.path.abspath(__file__))
root_dir = os.path.dirname(current_dir)

if root_dir not in sys.path:
    sys.path.insert(0, root_dir)
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

try:
    from backend.main import app
except Exception as e:
    import traceback
    traceback.print_exc()
    raise e
