from fastapi import APIRouter, Depends, HTTPException, status, Response
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel, EmailStr
from typing import Optional, Dict
import random

from backend.database import get_db
from backend.models.db_models import User, UserSettings
from backend.schemas.pydantic_schemas import UserRegister, UserLogin, UserResponse, Token
from backend.auth.security import verify_password, get_password_hash, create_access_token
from backend.auth.middleware import get_current_user
from backend.services.email_service import send_password_reset_email

router = APIRouter(prefix="/api/auth", tags=["Authentication"])

# In-Memory Cache for Verification Codes
RESET_OTP_CACHE: Dict[str, str] = {}

class ForgotPasswordRequest(BaseModel):
    email: EmailStr

class ResetPasswordRequest(BaseModel):
    email: EmailStr
    otp_code: str
    new_password: str


@router.post("/register", response_model=Token)
async def register(user_data: UserRegister, response: Response, db: AsyncSession = Depends(get_db)):
    # Check if email exists
    existing = await db.execute(select(User).where(User.email == user_data.email.lower()))
    if existing.scalar_one_or_none():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="An account with this email address already exists."
        )

    # Create new user
    new_user = User(
        email=user_data.email.lower(),
        full_name=user_data.full_name,
        hashed_password=get_password_hash(user_data.password)
    )
    db.add(new_user)
    await db.commit()
    await db.refresh(new_user)

    # Create default user settings
    default_settings = UserSettings(user_id=new_user.id)
    db.add(default_settings)
    await db.commit()

    # Generate Token
    access_token = create_access_token(data={"sub": str(new_user.id), "email": new_user.email})
    
    # Set HTTP-Only Cookie
    response.set_cookie(
        key="access_token",
        value=access_token,
        httponly=True,
        max_age=86400 * 30,
        samesite="lax"
    )

    return Token(
        access_token=access_token,
        token_type="bearer",
        user=UserResponse.model_validate(new_user)
    )


@router.post("/login", response_model=Token)
async def login(user_data: UserLogin, response: Response, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(User).where(User.email == user_data.email.lower()))
    user = result.scalar_one_or_none()

    if not user or not verify_password(user_data.password, user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email address or password."
        )

    access_token = create_access_token(data={"sub": str(user.id), "email": user.email})
    
    response.set_cookie(
        key="access_token",
        value=access_token,
        httponly=True,
        max_age=86400 * 30,
        samesite="lax"
    )

    return Token(
        access_token=access_token,
        token_type="bearer",
        user=UserResponse.model_validate(user)
    )


@router.post("/forgot-password")
async def forgot_password(payload: ForgotPasswordRequest, db: AsyncSession = Depends(get_db)):
    email = payload.email.lower()
    result = await db.execute(select(User).where(User.email == email))
    user = result.scalar_one_or_none()

    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="No registered account found with this email address."
        )

    # Generate 6-digit OTP code securely
    otp = str(random.randint(100000, 999999))
    RESET_OTP_CACHE[email] = otp

    # Send verification code to user's email inbox ONLY
    await send_password_reset_email(email, otp)

    # SECURE: Do NOT expose otp_code in API response
    return {
        "message": f"Security verification code sent to {email}. Please check your email inbox.",
        "email": email
    }


@router.post("/reset-password", response_model=Token)
async def reset_password(payload: ResetPasswordRequest, response: Response, db: AsyncSession = Depends(get_db)):
    email = payload.email.lower()
    cached_otp = RESET_OTP_CACHE.get(email)

    if not cached_otp or cached_otp != payload.otp_code.strip():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid or expired verification code."
        )

    result = await db.execute(select(User).where(User.email == email))
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Account not found."
        )

    # Update password securely in Supabase PostgreSQL DB
    user.hashed_password = get_password_hash(payload.new_password)
    await db.commit()
    await db.refresh(user)

    # Invalidate OTP code after single use
    RESET_OTP_CACHE.pop(email, None)

    access_token = create_access_token(data={"sub": str(user.id), "email": user.email})
    response.set_cookie(
        key="access_token",
        value=access_token,
        httponly=True,
        max_age=86400 * 30,
        samesite="lax"
    )

    return Token(
        access_token=access_token,
        token_type="bearer",
        user=UserResponse.model_validate(user)
    )


@router.get("/me", response_model=UserResponse)
async def get_me(current_user: User = Depends(get_current_user)):
    return UserResponse.model_validate(current_user)


@router.post("/logout")
async def logout(response: Response):
    response.delete_cookie("access_token")
    return {"message": "Successfully logged out of PEACOCK AI"}


@router.post("/guest", response_model=Token)
async def guest_login(response: Response, db: AsyncSession = Depends(get_db)):
    guest_email = "guest@peacock.ai"
    result = await db.execute(select(User).where(User.email == guest_email))
    user = result.scalar_one_or_none()

    if not user:
        user = User(
            email=guest_email,
            full_name="Peacock Guest",
            hashed_password=get_password_hash("guestpass123")
        )
        db.add(user)
        await db.commit()
        await db.refresh(user)

        default_settings = UserSettings(user_id=user.id)
        db.add(default_settings)
        await db.commit()

    access_token = create_access_token(data={"sub": str(user.id), "email": user.email})
    response.set_cookie(
        key="access_token",
        value=access_token,
        httponly=True,
        max_age=86400 * 30,
        samesite="lax"
    )

    return Token(
        access_token=access_token,
        token_type="bearer",
        user=UserResponse.model_validate(user)
    )
