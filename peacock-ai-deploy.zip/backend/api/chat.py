import json
import uuid
import datetime
from fastapi import APIRouter, Depends, HTTPException, status, Query
from fastapi.responses import StreamingResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from sqlalchemy.orm import selectinload
from backend.database import get_db, AsyncSessionLocal
from backend.models.db_models import User, Conversation, Message
from backend.schemas.pydantic_schemas import MessageCreate, MessageResponse, FeedbackUpdate
from backend.auth.middleware import get_current_user
from backend.providers.provider_manager import provider_manager

router = APIRouter(prefix="/api/chat", tags=["Chat & Streaming"])

def build_prompt_with_attachments(content: str, file_attachments: list) -> str:
    prompt_text = content or ""
    if not file_attachments:
        return prompt_text

    contexts = []
    for att in file_attachments:
        filename = att.get("filename", "file")
        extracted_text = att.get("extracted_text") or ""

        if extracted_text:
            if extracted_text.startswith("data:image"):
                contexts.append(f"[Attached Image: {filename}]\n(Image file '{filename}' uploaded by user for analysis)")
            else:
                contexts.append(f"--- Attached Document/File: {filename} ---\n{extracted_text}\n--- End of File: {filename} ---")

    if contexts:
        combined_context = "\n\n".join(contexts)
        if prompt_text:
            return f"{combined_context}\n\nUser Question: {prompt_text}"
        else:
            return f"{combined_context}\n\nPlease analyze the attached document/file in detail."

    return prompt_text

@router.post("", response_model=MessageResponse)
async def send_message(
    msg_data: MessageCreate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    result = await db.execute(
        select(Conversation)
        .options(selectinload(Conversation.messages))
        .where(Conversation.id == msg_data.conversation_id, Conversation.user_id == current_user.id)
    )
    conv = result.scalar_one_or_none()
    if not conv:
        raise HTTPException(status_code=404, detail="Conversation not found")

    model_id = msg_data.model_id or conv.model_id or "peacock_ultra"

    if len(conv.messages) == 0 and msg_data.content:
        new_title = msg_data.content[:40].strip() + "..."
        conv.title = new_title

    user_msg_id = str(uuid.uuid4())
    user_msg = Message(
        id=user_msg_id,
        conversation_id=conv.id,
        role="user",
        content=msg_data.content,
        model_id=model_id,
        file_attachments=msg_data.file_attachments or []
    )
    db.add(user_msg)

    formatted_messages = []
    for m in conv.messages:
        formatted_prompt = build_prompt_with_attachments(m.content, m.file_attachments or [])
        formatted_messages.append({"role": m.role, "content": formatted_prompt})

    current_prompt = build_prompt_with_attachments(msg_data.content, msg_data.file_attachments or [])
    formatted_messages.append({"role": "user", "content": current_prompt})

    ai_text = await provider_manager.chat(model_id, formatted_messages)

    assistant_msg_id = str(uuid.uuid4())
    assistant_msg = Message(
        id=assistant_msg_id,
        conversation_id=conv.id,
        role="assistant",
        content=ai_text,
        model_id=model_id
    )
    db.add(assistant_msg)

    conv.updated_at = datetime.datetime.utcnow()
    await db.commit()
    await db.refresh(assistant_msg)

    return MessageResponse.model_validate(assistant_msg)


@router.get("/stream")
async def stream_chat(
    conversation_id: str = Query(...),
    prompt: str = Query(...),
    model_id: str = Query("peacock_ultra"),
    file_attachments_json: str = Query("[]"),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    result = await db.execute(
        select(Conversation)
        .options(selectinload(Conversation.messages))
        .where(Conversation.id == conversation_id, Conversation.user_id == current_user.id)
    )
    conv = result.scalar_one_or_none()
    if not conv:
        raise HTTPException(status_code=404, detail="Conversation not found")

    try:
        attachments = json.loads(file_attachments_json)
    except Exception:
        attachments = []

    if len(conv.messages) == 0 and prompt:
        conv.title = prompt[:40].strip() + "..."

    user_msg_id = str(uuid.uuid4())
    user_msg = Message(
        id=user_msg_id,
        conversation_id=conv.id,
        role="user",
        content=prompt,
        model_id=model_id,
        file_attachments=attachments
    )
    db.add(user_msg)
    await db.commit()

    formatted_messages = []
    for m in conv.messages:
        formatted_prompt = build_prompt_with_attachments(m.content, m.file_attachments or [])
        formatted_messages.append({"role": m.role, "content": formatted_prompt})

    current_prompt = build_prompt_with_attachments(prompt, attachments)
    formatted_messages.append({"role": "user", "content": current_prompt})

    assistant_msg_id = str(uuid.uuid4())

    async def event_generator():
        full_response = []
        try:
            start_payload = json.dumps({"type": "start", "message_id": assistant_msg_id, "model_id": model_id})
            yield f"data: {start_payload}\n\n"

            async for token in provider_manager.stream_chat(model_id, formatted_messages):
                full_response.append(token)
                chunk_payload = json.dumps({"type": "chunk", "text": token})
                yield f"data: {chunk_payload}\n\n"

            final_text = "".join(full_response)

            async with AsyncSessionLocal() as async_db:
                asst_msg = Message(
                    id=assistant_msg_id,
                    conversation_id=conversation_id,
                    role="assistant",
                    content=final_text,
                    model_id=model_id
                )
                async_db.add(asst_msg)

                c_res = await async_db.execute(select(Conversation).where(Conversation.id == conversation_id))
                c_obj = c_res.scalar_one_or_none()
                if c_obj:
                    c_obj.updated_at = datetime.datetime.utcnow()
                await async_db.commit()

            end_payload = json.dumps({"type": "end", "message_id": assistant_msg_id, "full_text": final_text})
            yield f"data: {end_payload}\n\n"

        except Exception as e:
            err_payload = json.dumps({"type": "error", "error": str(e)})
            yield f"data: {err_payload}\n\n"

    return StreamingResponse(event_generator(), media_type="text/event-stream")


@router.patch("/messages/{msg_id}/feedback")
async def update_message_feedback(
    msg_id: str,
    fb_data: FeedbackUpdate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    result = await db.execute(select(Message).where(Message.id == msg_id))
    msg = result.scalar_one_or_none()
    if not msg:
        raise HTTPException(status_code=404, detail="Message not found")

    msg.feedback = fb_data.feedback
    await db.commit()
    return {"message": "Feedback updated", "id": msg_id, "feedback": msg.feedback}
