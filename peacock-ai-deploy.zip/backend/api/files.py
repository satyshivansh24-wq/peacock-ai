from typing import List, Optional
from fastapi import APIRouter, Depends, UploadFile, File, Form, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from backend.database import get_db
from backend.models.db_models import User, UploadedFile
from backend.services.file_service import process_and_save_file
from backend.auth.middleware import get_current_user

router = APIRouter(prefix="/api/files", tags=["Files"])

@router.post("/upload")
async def upload_file_endpoint(
    file: UploadFile = File(...),
    conversation_id: Optional[str] = Form(None),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    saved_info = await process_and_save_file(file, conversation_id)
    
    db_file = UploadedFile(
        id=saved_info["id"],
        user_id=current_user.id,
        conversation_id=conversation_id,
        filename=saved_info["filename"],
        file_path=saved_info["file_path"],
        file_type=saved_info["file_type"],
        file_size=saved_info["file_size"],
        extracted_text=saved_info["extracted_text"]
    )
    db.add(db_file)
    await db.commit()
    await db.refresh(db_file)

    return {
        "id": db_file.id,
        "filename": db_file.filename,
        "file_type": db_file.file_type,
        "file_size": db_file.file_size,
        "extracted_text": db_file.extracted_text[:1000] if db_file.extracted_text else None
    }

@router.get("")
async def list_user_files(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    result = await db.execute(
        select(UploadedFile)
        .where(UploadedFile.user_id == current_user.id)
        .order_by(UploadedFile.uploaded_at.desc())
    )
    files = result.scalars().all()
    return [
        {
            "id": f.id,
            "filename": f.filename,
            "file_type": f.file_type,
            "file_size": f.file_size,
            "uploaded_at": f.uploaded_at
        }
        for f in files
    ]

@router.delete("/{file_id}")
async def delete_file_endpoint(
    file_id: str,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    result = await db.execute(
        select(UploadedFile).where(UploadedFile.id == file_id, UploadedFile.user_id == current_user.id)
    )
    f = result.scalar_one_or_none()
    if not f:
        raise HTTPException(status_code=404, detail="File not found")

    await db.delete(f)
    await db.commit()
    return {"message": "File deleted", "id": file_id}
