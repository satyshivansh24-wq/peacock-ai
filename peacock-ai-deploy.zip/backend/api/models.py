from typing import List
from fastapi import APIRouter
from backend.schemas.pydantic_schemas import AIModelCard, ProviderStatus
from backend.providers.provider_manager import provider_manager

router = APIRouter(prefix="/api/models", tags=["AI Models & Providers"])

@router.get("", response_model=List[AIModelCard])
async def get_all_models():
    return provider_manager.get_all_models()

@router.get("/statuses", response_model=List[ProviderStatus])
async def get_provider_statuses():
    return provider_manager.get_provider_statuses()
