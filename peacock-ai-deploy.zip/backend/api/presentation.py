from fastapi import APIRouter

router = APIRouter(prefix="/api/presentation", tags=["College Presentation"])

@router.get("/about")
async def get_about_info():
    return {
        "title": "PEACOCK AI",
        "tagline": "15 Colors. 15 AI Powers. One Intelligent Assistant.",
        "subtitle": "One interface. Multiple AI minds.",
        "description": "PEACOCK AI is a multi-AI chatbot platform designed as a college project to demonstrate how multiple artificial intelligence services can be integrated into a single intelligent conversational interface.",
        "concept": "Peacock → 15 prominent colors → PEACOCK AI → 15 AI tools/models",
        "architecture_flow": [
            {"step": 1, "name": "User Query", "desc": "User submits text, voice, image, or document prompt"},
            {"step": 2, "name": "PEACOCK AI Frontend", "desc": "Glassmorphic 15-color animated web client"},
            {"step": 3, "name": "FastAPI Backend", "desc": "REST API, JWT Authentication, and SSE Streaming pipeline"},
            {"step": 4, "name": "AI Provider Manager", "desc": "Central registry handling routing, availability & fallbacks"},
            {"step": 5, "name": "15 AI Providers", "desc": "Modular providers (OpenAI, Claude, Gemini, DeepSeek, Demo Engine)"},
            {"step": 6, "name": "Stream Response", "desc": "Progressive token rendering with markdown & code syntax highlighting"}
        ],
        "colors": [
            {"name": "Peacock Blue", "hex": "#0F4C81", "model": "Peacock Ultra"},
            {"name": "Royal Blue", "hex": "#1E40AF", "model": "GPT-4o Mind"},
            {"name": "Cyan", "hex": "#06B6D4", "model": "Claude 3.5 Sonnet"},
            {"name": "Turquoise", "hex": "#14B8A6", "model": "Gemini 1.5 Flash"},
            {"name": "Teal", "hex": "#0D9488", "model": "DeepSeek R1/V3"},
            {"name": "Emerald", "hex": "#10B981", "model": "Llama 3.3 70B"},
            {"name": "Green", "hex": "#22C55E", "model": "Mistral Large"},
            {"name": "Lime", "hex": "#84CC16", "model": "Qwen 2.5 Max"},
            {"name": "Gold", "hex": "#EAB308", "model": "Command R+"},
            {"name": "Yellow", "hex": "#FACC15", "model": "Perplexity Sonar"},
            {"name": "Orange", "hex": "#F97316", "model": "Grok 2 Vision"},
            {"name": "Coral", "hex": "#FF6B6B", "model": "Phind Code Pro"},
            {"name": "Pink", "hex": "#EC4899", "model": "Together Vision"},
            {"name": "Purple", "hex": "#A855F7", "model": "Fireworks Stream"},
            {"name": "Indigo", "hex": "#6366F1", "model": "Peacock Demo AI"}
        ]
    }
