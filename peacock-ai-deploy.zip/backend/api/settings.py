from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from backend.database import get_db
from backend.models.db_models import User, UserSettings
from backend.schemas.pydantic_schemas import UserSettingsUpdate, UserSettingsResponse
from backend.auth.middleware import get_current_user

router = APIRouter(prefix="/api/settings", tags=["Settings"])

@router.get("", response_model=UserSettingsResponse)
async def get_user_settings(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    result = await db.execute(select(UserSettings).where(UserSettings.user_id == current_user.id))
    user_settings = result.scalar_one_or_none()
    
    if not user_settings:
        user_settings = UserSettings(user_id=current_user.id)
        db.add(user_settings)
        await db.commit()
        await db.refresh(user_settings)

    return UserSettingsResponse.model_validate(user_settings)

@router.put("", response_model=UserSettingsResponse)
async def update_user_settings(
    settings_data: UserSettingsUpdate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    result = await db.execute(select(UserSettings).where(UserSettings.user_id == current_user.id))
    user_settings = result.scalar_one_or_none()

    if not user_settings:
        user_settings = UserSettings(user_id=current_user.id)
        db.add(user_settings)

    if settings_data.theme is not None:
        user_settings.theme = settings_data.theme
    if settings_data.default_model is not None:
        user_settings.default_model = settings_data.default_model
    if settings_data.response_language is not None:
        user_settings.response_language = settings_data.response_language
    if settings_data.enter_to_send is not None:
        user_settings.enter_to_send = settings_data.enter_to_send
    if settings_data.streaming_enabled is not None:
        user_settings.streaming_enabled = settings_data.streaming_enabled

    await db.commit()
    await db.refresh(user_settings)
    return UserSettingsResponse.model_validate(user_settings)
