import os
from pydantic_settings import BaseSettings
from typing import Optional
from pydantic import ConfigDict

IS_VERCEL = bool(os.environ.get("VERCEL"))

default_db_url = "sqlite+aiosqlite:////tmp/peacock_ai.db" if IS_VERCEL else "sqlite+aiosqlite:///./peacock_ai.db"
default_upload_dir = "/tmp/uploads" if IS_VERCEL else "./uploads"

class Settings(BaseSettings):
    APP_NAME: str = "PEACOCK AI"
    TAGLINE: str = "15 Colors. 15 AI Powers. One Intelligent Assistant."
    SUBTITLE: str = "One interface. Multiple AI minds."

    SECRET_KEY: str = "peacock_ai_super_secret_jwt_key_2026_change_in_production"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 1440

    DATABASE_URL: str = default_db_url
    UPLOAD_DIR: str = default_upload_dir

    # SMTP Email Settings
    SMTP_HOST: str = "smtp.gmail.com"
    SMTP_PORT: int = 587
    SMTP_USER: Optional[str] = None
    SMTP_PASSWORD: Optional[str] = None
    EMAIL_FROM: str = "noreply@peacock.ai"

    # OpenRouter Single API Key
    OPENROUTER_API_KEY: Optional[str] = None

    # 15 Provider API Keys
    AI_PROVIDER_01_API_KEY: Optional[str] = None
    AI_PROVIDER_02_API_KEY: Optional[str] = None
    AI_PROVIDER_03_API_KEY: Optional[str] = None
    AI_PROVIDER_04_API_KEY: Optional[str] = None
    AI_PROVIDER_05_API_KEY: Optional[str] = None
    AI_PROVIDER_06_API_KEY: Optional[str] = None
    AI_PROVIDER_07_API_KEY: Optional[str] = None
    AI_PROVIDER_08_API_KEY: Optional[str] = None
    AI_PROVIDER_09_API_KEY: Optional[str] = None
    AI_PROVIDER_10_API_KEY: Optional[str] = None
    AI_PROVIDER_11_API_KEY: Optional[str] = None
    AI_PROVIDER_12_API_KEY: Optional[str] = None
    AI_PROVIDER_13_API_KEY: Optional[str] = None
    AI_PROVIDER_14_API_KEY: Optional[str] = None
    AI_PROVIDER_15_API_KEY: Optional[str] = "peacock_demo_default_key"

    model_config = ConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

settings = Settings()

# Safe directory creation for Serverless environments
try:
    os.makedirs(settings.UPLOAD_DIR, exist_ok=True)
except Exception:
    pass
