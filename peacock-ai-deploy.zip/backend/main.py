import os
from contextlib import asynccontextmanager
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from backend.config import settings
from backend.database import init_db
from backend.api import auth, conversations, chat, files, models, settings as settings_api, presentation

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Initialize Database tables safely
    try:
        await init_db()
    except Exception:
        pass
    yield

app = FastAPI(
    title=settings.APP_NAME,
    description="Multi-AI Chatbot Platform — 15 Colors. 15 AI Powers. One Intelligent Assistant.",
    version="2.0.0",
    lifespan=lifespan
)

# CORS Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount Static Files & Uploads
base_dir = os.path.dirname(os.path.dirname(__file__))
static_dir = os.path.join(base_dir, "frontend", "static")
templates_dir = os.path.join(base_dir, "frontend", "templates")

try:
    os.makedirs(static_dir, exist_ok=True)
    os.makedirs(templates_dir, exist_ok=True)
    os.makedirs(settings.UPLOAD_DIR, exist_ok=True)
except Exception:
    pass

app.mount("/static", StaticFiles(directory=static_dir), name="static")

try:
    app.mount("/uploads", StaticFiles(directory=settings.UPLOAD_DIR), name="uploads")
except Exception:
    pass

templates = Jinja2Templates(directory=templates_dir)

# Mount API Routers
app.include_router(auth.router)
app.include_router(conversations.router)
app.include_router(chat.router)
app.include_router(files.router)
app.include_router(models.router)
app.include_router(settings_api.router)
app.include_router(presentation.router)

@app.get("/")
async def root(request: Request):
    return templates.TemplateResponse(request=request, name="index.html", context={"app_name": settings.APP_NAME})
