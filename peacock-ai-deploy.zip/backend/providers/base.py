from abc import ABC, abstractmethod
from typing import List, AsyncGenerator, Dict, Any, Optional
import httpx
import json
import urllib.parse
from backend.schemas.pydantic_schemas import AIModelCard
from backend.config import settings

PEACOCK_SYSTEM_PROMPT = {
    "role": "system",
    "content": (
        "You are PEACOCK AI, a master multi-modal AI platform unifying 15 specialized AI engines under a unified interface.\n\n"
        "DIRECTIVES FOR FILE ANALYSIS, IMAGE GENERATION & PDF CREATION:\n"
        "1. VISUAL & FILE ANALYSIS: You possess full document and file analysis capabilities. When prompt text contains attached file text, document contents, or image descriptions (e.g., '--- Attached Document/File ---' or '[Attached Image]'), analyze the provided contents thoroughly. NEVER claim that you cannot view or analyze files/images.\n"
        "2. IMAGE CREATION: If the user asks to generate, create, draw, or render an image (e.g., 'create an image of X', 'draw a Y'), ALWAYS generate a real AI image by returning a Markdown image tag using Pollinations AI format:\n"
        "   ![Generated Image](https://image.pollinations.ai/prompt/URL_ENCODED_ENGLISH_PROMPT?width=1024&height=1024&nologo=true)\n"
        "   Do not claim you cannot create images—simply provide the markdown image link along with a friendly description!\n"
        "3. PDF & DOCUMENT CREATION: If the user asks to create a PDF or document, generate a complete, beautifully formatted Markdown document with titles, sections, tables, and bullet points ready to print or save.\n"
        "4. TONE: Intelligent, polite, clear, and confident."
    )
}

class BaseAIProvider(ABC):
    """
    Abstract Base Class for all 15 PEACOCK AI Providers.
    Each provider represents one of the 15 Peacock colors and AI minds.
    """

    @abstractmethod
    def get_metadata(self) -> AIModelCard:
        """Returns the model card metadata including colors, speed, capabilities."""
        pass

    def get_api_key(self, provider_specific_key: Optional[str] = None) -> Optional[str]:
        """Gets provider key or falls back to global OPENROUTER_API_KEY."""
        return provider_specific_key or settings.OPENROUTER_API_KEY

    def is_configured(self) -> bool:
        """Returns True if any API key is configured."""
        return bool(self.get_api_key())

    @abstractmethod
    async def chat(self, messages: List[Dict[str, Any]], options: Optional[Dict[str, Any]] = None) -> str:
        """Generates a complete chat response."""
        pass

    @abstractmethod
    async def stream_chat(self, messages: List[Dict[str, Any]], options: Optional[Dict[str, Any]] = None) -> AsyncGenerator[str, None]:
        """Streams chat tokens asynchronously."""
        pass

    async def _call_openrouter_chat(self, model_slug: str, messages: List[Dict[str, Any]], custom_key: Optional[str] = None) -> Optional[str]:
        api_key = self.get_api_key(custom_key)
        if not api_key:
            return None

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "HTTP-Referer": "http://127.0.0.1:8000",
            "X-Title": "PEACOCK AI"
        }

        has_system = any(m.get("role") == "system" for m in messages)
        final_messages = messages if has_system else [PEACOCK_SYSTEM_PROMPT] + messages

        payload = {
            "model": model_slug,
            "messages": final_messages,
            "max_tokens": 2500,
            "temperature": 0.7
        }

        try:
            async with httpx.AsyncClient() as client:
                res = await client.post("https://openrouter.ai/api/v1/chat/completions", headers=headers, json=payload, timeout=30.0)
                if res.status_code == 200:
                    data = res.json()
                    return data["choices"][0]["message"]["content"]
                else:
                    # Fallback to secondary fast model if 404 or credit issue
                    payload["model"] = "meta-llama/llama-3.1-8b-instruct"
                    res2 = await client.post("https://openrouter.ai/api/v1/chat/completions", headers=headers, json=payload, timeout=30.0)
                    if res2.status_code == 200:
                        return res2.json()["choices"][0]["message"]["content"]
        except Exception:
            pass
        return None

    async def _call_openrouter_stream(self, model_slug: str, messages: List[Dict[str, Any]], custom_key: Optional[str] = None) -> AsyncGenerator[str, None]:
        api_key = self.get_api_key(custom_key)
        if not api_key:
            return

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "HTTP-Referer": "http://127.0.0.1:8000",
            "X-Title": "PEACOCK AI"
        }

        has_system = any(m.get("role") == "system" for m in messages)
        final_messages = messages if has_system else [PEACOCK_SYSTEM_PROMPT] + messages

        payload = {
            "model": model_slug,
            "messages": final_messages,
            "stream": True,
            "max_tokens": 2500,
            "temperature": 0.7
        }

        try:
            async with httpx.AsyncClient() as client:
                async with client.stream("POST", "https://openrouter.ai/api/v1/chat/completions", headers=headers, json=payload, timeout=30.0) as res:
                    if res.status_code == 200:
                        async for line in res.aiter_lines():
                            if line.startswith("data: ") and line != "data: [DONE]":
                                try:
                                    data = json.loads(line[6:])
                                    delta = data["choices"][0]["delta"].get("content", "")
                                    if delta:
                                        yield delta
                                except Exception:
                                    pass
                        return
                    else:
                        # Fallback stream with llama 3.1 8b
                        payload["model"] = "meta-llama/llama-3.1-8b-instruct"
                        async with client.stream("POST", "https://openrouter.ai/api/v1/chat/completions", headers=headers, json=payload, timeout=30.0) as res2:
                            if res2.status_code == 200:
                                async for line in res2.aiter_lines():
                                    if line.startswith("data: ") and line != "data: [DONE]":
                                        try:
                                            data = json.loads(line[6:])
                                            delta = data["choices"][0]["delta"].get("content", "")
                                            if delta:
                                                yield delta
                                        except Exception:
                                            pass
                                return
        except Exception:
            pass

    async def analyze_image(self, image_data_b64: str, prompt: str, options: Optional[Dict[str, Any]] = None) -> str:
        """Analyzes an image and returns an explanation."""
        metadata = self.get_metadata()
        if not metadata.supports_vision:
            return "⚠️ **Model Capability Notice**: This selected AI model does not support image analysis. Please select a vision-capable model like **GPT-4o Mind**, **Gemini 1.5 Flash**, **Together Vision**, or **Grok 2**."
        return await self.chat([{"role": "user", "content": f"{prompt}\n[Image Attached]"}], options)

    async def analyze_file(self, file_content: str, filename: str, prompt: str, options: Optional[Dict[str, Any]] = None) -> str:
        """Analyzes a document file content and answers questions."""
        combined_prompt = f"File Context ({filename}):\n```\n{file_content[:15000]}\n```\n\nUser Question: {prompt}"
        return await self.chat([{"role": "user", "content": combined_prompt}], options)
