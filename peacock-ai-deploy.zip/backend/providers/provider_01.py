from typing import List, AsyncGenerator, Dict, Any, Optional
from backend.providers.base import BaseAIProvider
from backend.schemas.pydantic_schemas import AIModelCard
from backend.config import settings

class PeacockUltraProvider(BaseAIProvider):
    MODEL_SLUG = "openai/gpt-4o-mini"

    def get_metadata(self) -> AIModelCard:
        is_live = bool(self.get_api_key())
        return AIModelCard(
            id="peacock_ultra",
            name="Peacock Ultra",
            tagline="Master General Intelligence & Orchestrator",
            provider="PEACOCK Core",
            color_name="Peacock Blue",
            color_hex="#0F4C81",
            badge_bg="rgba(15, 76, 129, 0.2)",
            icon="feather",
            description="Our flagship master AI intelligence tuned for complex conversations, reasoning, and multi-domain problem solving.",
            speed_rating=5,
            capabilities=["Chat", "Coding", "Reasoning", "Documents", "Multi-lingual"],
            supports_vision=True,
            supports_documents=True,
            supports_code=True,
            status="LIVE" if is_live else "DEMO",
            is_demo_fallback=not is_live
        )

    async def chat(self, messages: List[Dict[str, Any]], options: Optional[Dict[str, Any]] = None) -> str:
        res = await self._call_openrouter_chat(self.MODEL_SLUG, messages, settings.AI_PROVIDER_01_API_KEY)
        if res:
            return res
        from backend.providers.provider_15 import PeacockDemoProvider
        return await PeacockDemoProvider().generate_demo_response("Peacock Ultra", messages)

    async def stream_chat(self, messages: List[Dict[str, Any]], options: Optional[Dict[str, Any]] = None) -> AsyncGenerator[str, None]:
        streamed = False
        async for token in self._call_openrouter_stream(self.MODEL_SLUG, messages, settings.AI_PROVIDER_01_API_KEY):
            streamed = True
            yield token

        if not streamed:
            from backend.providers.provider_15 import PeacockDemoProvider
            async for token in PeacockDemoProvider().generate_demo_stream("Peacock Ultra", messages):
                yield token
