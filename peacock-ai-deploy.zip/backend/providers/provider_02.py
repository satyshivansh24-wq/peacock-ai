from typing import List, AsyncGenerator, Dict, Any, Optional
from backend.providers.base import BaseAIProvider
from backend.schemas.pydantic_schemas import AIModelCard
from backend.config import settings

class GPT4oMindProvider(BaseAIProvider):
    MODEL_SLUG = "openai/gpt-4o-mini"

    def get_metadata(self) -> AIModelCard:
        is_live = bool(self.get_api_key())
        return AIModelCard(
            id="gpt4o_mind",
            name="GPT-4o Mind",
            tagline="Advanced Multi-Modal & Reasoning Engine",
            provider="OpenAI",
            color_name="Royal Blue",
            color_hex="#1E40AF",
            badge_bg="rgba(30, 64, 175, 0.2)",
            icon="cpu",
            description="State-of-the-art vision, audio, text, and logical reasoning capability across complex data.",
            speed_rating=5,
            capabilities=["Vision", "Reasoning", "Coding", "Documents", "Chat"],
            supports_vision=True,
            supports_documents=True,
            supports_code=True,
            status="LIVE" if is_live else "DEMO",
            is_demo_fallback=not is_live
        )

    async def chat(self, messages: List[Dict[str, Any]], options: Optional[Dict[str, Any]] = None) -> str:
        res = await self._call_openrouter_chat(self.MODEL_SLUG, messages, settings.AI_PROVIDER_02_API_KEY)
        if res:
            return res
        from backend.providers.provider_15 import PeacockDemoProvider
        return await PeacockDemoProvider().generate_demo_response("GPT-4o Mind", messages)

    async def stream_chat(self, messages: List[Dict[str, Any]], options: Optional[Dict[str, Any]] = None) -> AsyncGenerator[str, None]:
        streamed = False
        async for token in self._call_openrouter_stream(self.MODEL_SLUG, messages, settings.AI_PROVIDER_02_API_KEY):
            streamed = True
            yield token

        if not streamed:
            from backend.providers.provider_15 import PeacockDemoProvider
            async for token in PeacockDemoProvider().generate_demo_stream("GPT-4o Mind", messages):
                yield token
