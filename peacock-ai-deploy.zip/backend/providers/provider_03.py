from typing import List, AsyncGenerator, Dict, Any, Optional
from backend.providers.base import BaseAIProvider
from backend.schemas.pydantic_schemas import AIModelCard
from backend.config import settings

class ClaudeSonnetProvider(BaseAIProvider):
    MODEL_SLUG = "anthropic/claude-3-haiku"

    def get_metadata(self) -> AIModelCard:
        is_live = bool(self.get_api_key())
        return AIModelCard(
            id="claude_35_sonnet",
            name="Claude 3.5 Sonnet",
            tagline="Creative Coding, Architecture & Technical Writing",
            provider="Anthropic",
            color_name="Cyan",
            color_hex="#06B6D4",
            badge_bg="rgba(6, 182, 212, 0.2)",
            icon="code",
            description="Excellence in software engineering, complex system architecture design, and nuanced creative writing.",
            speed_rating=4,
            capabilities=["Coding", "Architecture", "Writing", "Analysis"],
            supports_vision=True,
            supports_documents=True,
            supports_code=True,
            status="LIVE" if is_live else "DEMO",
            is_demo_fallback=not is_live
        )

    async def chat(self, messages: List[Dict[str, Any]], options: Optional[Dict[str, Any]] = None) -> str:
        res = await self._call_openrouter_chat(self.MODEL_SLUG, messages, settings.AI_PROVIDER_03_API_KEY)
        if res:
            return res
        from backend.providers.provider_15 import PeacockDemoProvider
        return await PeacockDemoProvider().generate_demo_response("Claude 3.5 Sonnet", messages)

    async def stream_chat(self, messages: List[Dict[str, Any]], options: Optional[Dict[str, Any]] = None) -> AsyncGenerator[str, None]:
        streamed = False
        async for token in self._call_openrouter_stream(self.MODEL_SLUG, messages, settings.AI_PROVIDER_03_API_KEY):
            streamed = True
            yield token

        if not streamed:
            from backend.providers.provider_15 import PeacockDemoProvider
            async for token in PeacockDemoProvider().generate_demo_stream("Claude 3.5 Sonnet", messages):
                yield token
