from typing import List, AsyncGenerator, Dict, Any, Optional
from backend.providers.base import BaseAIProvider
from backend.schemas.pydantic_schemas import AIModelCard
from backend.config import settings

class GeminiFlashProvider(BaseAIProvider):
    MODEL_SLUG = "google/gemini-2.5-flash"

    def get_metadata(self) -> AIModelCard:
        is_live = bool(self.get_api_key())
        return AIModelCard(
            id="gemini_15_flash",
            name="Gemini 1.5 Flash",
            tagline="Ultra-Fast 1M+ Token Context Window",
            provider="Google DeepMind",
            color_name="Turquoise",
            color_hex="#14B8A6",
            badge_bg="rgba(20, 184, 166, 0.2)",
            icon="zap",
            description="Ultra low-latency processing powered by 1 Million+ token context capacity for massive document and video analysis.",
            speed_rating=5,
            capabilities=["1M Context", "Fast Chat", "Documents", "Vision"],
            supports_vision=True,
            supports_documents=True,
            supports_code=True,
            status="LIVE" if is_live else "DEMO",
            is_demo_fallback=not is_live
        )

    async def chat(self, messages: List[Dict[str, Any]], options: Optional[Dict[str, Any]] = None) -> str:
        res = await self._call_openrouter_chat(self.MODEL_SLUG, messages, settings.AI_PROVIDER_04_API_KEY)
        if res:
            return res
        from backend.providers.provider_15 import PeacockDemoProvider
        return await PeacockDemoProvider().generate_demo_response("Gemini 1.5 Flash", messages)

    async def stream_chat(self, messages: List[Dict[str, Any]], options: Optional[Dict[str, Any]] = None) -> AsyncGenerator[str, None]:
        streamed = False
        async for token in self._call_openrouter_stream(self.MODEL_SLUG, messages, settings.AI_PROVIDER_04_API_KEY):
            streamed = True
            yield token

        if not streamed:
            from backend.providers.provider_15 import PeacockDemoProvider
            async for token in PeacockDemoProvider().generate_demo_stream("Gemini 1.5 Flash", messages):
                yield token
