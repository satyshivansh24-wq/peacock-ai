from typing import List, AsyncGenerator, Dict, Any, Optional
from backend.providers.base import BaseAIProvider
from backend.schemas.pydantic_schemas import AIModelCard
from backend.config import settings

class DeepSeekR1Provider(BaseAIProvider):
    MODEL_SLUG = "deepseek/deepseek-chat"

    def get_metadata(self) -> AIModelCard:
        is_live = bool(self.get_api_key())
        return AIModelCard(
            id="deepseek_r1",
            name="DeepSeek R1",
            tagline="Chain-of-Thought Logical Reasoning & Math",
            provider="DeepSeek",
            color_name="Teal",
            color_hex="#0D9488",
            badge_bg="rgba(13, 148, 136, 0.2)",
            icon="brain",
            description="Deep mathematical reasoning engine utilizing explicit chain-of-thought verification for complex logic problems.",
            speed_rating=4,
            capabilities=["Reasoning", "Math", "Logic", "Coding"],
            supports_vision=False,
            supports_documents=True,
            supports_code=True,
            status="LIVE" if is_live else "DEMO",
            is_demo_fallback=not is_live
        )

    async def chat(self, messages: List[Dict[str, Any]], options: Optional[Dict[str, Any]] = None) -> str:
        res = await self._call_openrouter_chat(self.MODEL_SLUG, messages, settings.AI_PROVIDER_05_API_KEY)
        if res:
            return res
        from backend.providers.provider_15 import PeacockDemoProvider
        return await PeacockDemoProvider().generate_demo_response("DeepSeek R1", messages)

    async def stream_chat(self, messages: List[Dict[str, Any]], options: Optional[Dict[str, Any]] = None) -> AsyncGenerator[str, None]:
        streamed = False
        async for token in self._call_openrouter_stream(self.MODEL_SLUG, messages, settings.AI_PROVIDER_05_API_KEY):
            streamed = True
            yield token

        if not streamed:
            from backend.providers.provider_15 import PeacockDemoProvider
            async for token in PeacockDemoProvider().generate_demo_stream("DeepSeek R1", messages):
                yield token
