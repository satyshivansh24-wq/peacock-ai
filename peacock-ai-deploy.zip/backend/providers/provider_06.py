from typing import List, AsyncGenerator, Dict, Any, Optional
from backend.providers.base import BaseAIProvider
from backend.schemas.pydantic_schemas import AIModelCard
from backend.config import settings

class LlamaProvider(BaseAIProvider):
    MODEL_SLUG = "meta-llama/llama-3.3-70b-instruct"

    def get_metadata(self) -> AIModelCard:
        is_live = bool(self.get_api_key())
        return AIModelCard(
            id="llama_33_70b",
            name="Llama 3.3 70B",
            tagline="Open-Weights Flagship Intelligence",
            provider="Meta AI",
            color_name="Emerald",
            color_hex="#059669",
            badge_bg="rgba(5, 150, 105, 0.2)",
            icon="cpu",
            description="Meta's top-tier open weight model delivering frontier performance across coding, reasoning, and multi-turn dialogue.",
            speed_rating=5,
            capabilities=["Open Source", "Coding", "Dialogue", "General Knowledge"],
            supports_vision=False,
            supports_documents=True,
            supports_code=True,
            status="LIVE" if is_live else "DEMO",
            is_demo_fallback=not is_live
        )

    async def chat(self, messages: List[Dict[str, Any]], options: Optional[Dict[str, Any]] = None) -> str:
        res = await self._call_openrouter_chat(self.MODEL_SLUG, messages, settings.AI_PROVIDER_06_API_KEY)
        if res:
            return res
        from backend.providers.provider_15 import PeacockDemoProvider
        return await PeacockDemoProvider().generate_demo_response("Llama 3.3 70B", messages)

    async def stream_chat(self, messages: List[Dict[str, Any]], options: Optional[Dict[str, Any]] = None) -> AsyncGenerator[str, None]:
        streamed = False
        async for token in self._call_openrouter_stream(self.MODEL_SLUG, messages, settings.AI_PROVIDER_06_API_KEY):
            streamed = True
            yield token

        if not streamed:
            from backend.providers.provider_15 import PeacockDemoProvider
            async for token in PeacockDemoProvider().generate_demo_stream("Llama 3.3 70B", messages):
                yield token
