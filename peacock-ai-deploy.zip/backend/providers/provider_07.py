from typing import List, AsyncGenerator, Dict, Any, Optional
from backend.providers.base import BaseAIProvider
from backend.schemas.pydantic_schemas import AIModelCard
from backend.config import settings

class MistralLargeProvider(BaseAIProvider):
    MODEL_SLUG = "meta-llama/llama-3.1-8b-instruct"

    def get_metadata(self) -> AIModelCard:
        is_live = bool(self.get_api_key())
        return AIModelCard(
            id="mistral_large",
            name="Mistral Large 2",
            tagline="European Precision & Multi-Lingual Nuance",
            provider="Mistral AI",
            color_name="Green",
            color_hex="#16A34A",
            badge_bg="rgba(22, 163, 74, 0.2)",
            icon="globe",
            description="Flagship European AI reasoning engine with exceptional multi-lingual fluency across European and Asian languages.",
            speed_rating=4,
            capabilities=["Multi-lingual", "Reasoning", "Writing", "Coding"],
            supports_vision=False,
            supports_documents=True,
            supports_code=True,
            status="LIVE" if is_live else "DEMO",
            is_demo_fallback=not is_live
        )

    async def chat(self, messages: List[Dict[str, Any]], options: Optional[Dict[str, Any]] = None) -> str:
        res = await self._call_openrouter_chat(self.MODEL_SLUG, messages, settings.AI_PROVIDER_07_API_KEY)
        if res:
            return res
        from backend.providers.provider_15 import PeacockDemoProvider
        return await PeacockDemoProvider().generate_demo_response("Mistral Large 2", messages)

    async def stream_chat(self, messages: List[Dict[str, Any]], options: Optional[Dict[str, Any]] = None) -> AsyncGenerator[str, None]:
        streamed = False
        async for token in self._call_openrouter_stream(self.MODEL_SLUG, messages, settings.AI_PROVIDER_07_API_KEY):
            streamed = True
            yield token

        if not streamed:
            from backend.providers.provider_15 import PeacockDemoProvider
            async for token in PeacockDemoProvider().generate_demo_stream("Mistral Large 2", messages):
                yield token
