from typing import List, AsyncGenerator, Dict, Any, Optional
from backend.providers.base import BaseAIProvider
from backend.schemas.pydantic_schemas import AIModelCard
from backend.config import settings

class QwenMaxProvider(BaseAIProvider):
    MODEL_SLUG = "qwen/qwen-2.5-72b-instruct"

    def get_metadata(self) -> AIModelCard:
        is_live = bool(self.get_api_key())
        return AIModelCard(
            id="qwen_25_max",
            name="Qwen 2.5 Max",
            tagline="Alibaba Master Multi-Lingual & Technical Intelligence",
            provider="Alibaba Cloud",
            color_name="Lime",
            color_hex="#84CC16",
            badge_bg="rgba(132, 204, 22, 0.2)",
            icon="code",
            description="State-of-the-art technical, math, and multi-lingual coding model benchmarked against top proprietary LLMs.",
            speed_rating=5,
            capabilities=["Coding", "Math", "Multi-lingual", "Reasoning"],
            supports_vision=False,
            supports_documents=True,
            supports_code=True,
            status="LIVE" if is_live else "DEMO",
            is_demo_fallback=not is_live
        )

    async def chat(self, messages: List[Dict[str, Any]], options: Optional[Dict[str, Any]] = None) -> str:
        res = await self._call_openrouter_chat(self.MODEL_SLUG, messages, settings.AI_PROVIDER_08_API_KEY)
        if res:
            return res
        from backend.providers.provider_15 import PeacockDemoProvider
        return await PeacockDemoProvider().generate_demo_response("Qwen 2.5 Max", messages)

    async def stream_chat(self, messages: List[Dict[str, Any]], options: Optional[Dict[str, Any]] = None) -> AsyncGenerator[str, None]:
        streamed = False
        async for token in self._call_openrouter_stream(self.MODEL_SLUG, messages, settings.AI_PROVIDER_08_API_KEY):
            streamed = True
            yield token

        if not streamed:
            from backend.providers.provider_15 import PeacockDemoProvider
            async for token in PeacockDemoProvider().generate_demo_stream("Qwen 2.5 Max", messages):
                yield token
