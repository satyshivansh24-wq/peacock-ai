from typing import List, AsyncGenerator, Dict, Any, Optional
from backend.providers.base import BaseAIProvider
from backend.schemas.pydantic_schemas import AIModelCard
from backend.config import settings

class CommandRPlusProvider(BaseAIProvider):
    MODEL_SLUG = "meta-llama/llama-3.1-8b-instruct"

    def get_metadata(self) -> AIModelCard:
        is_live = bool(self.get_api_key())
        return AIModelCard(
            id="command_r_plus",
            name="Command R+",
            tagline="Enterprise RAG & Citations Engine",
            provider="Cohere",
            color_name="Gold",
            color_hex="#EAB308",
            badge_bg="rgba(234, 179, 8, 0.2)",
            icon="search",
            description="Built specifically for enterprise Retrieval-Augmented Generation (RAG), tool use, and grounded citation analysis.",
            speed_rating=4,
            capabilities=["RAG", "Citations", "Enterprise", "Documents"],
            supports_vision=False,
            supports_documents=True,
            supports_code=True,
            status="LIVE" if is_live else "DEMO",
            is_demo_fallback=not is_live
        )

    async def chat(self, messages: List[Dict[str, Any]], options: Optional[Dict[str, Any]] = None) -> str:
        res = await self._call_openrouter_chat(self.MODEL_SLUG, messages, settings.AI_PROVIDER_09_API_KEY)
        if res:
            return res
        from backend.providers.provider_15 import PeacockDemoProvider
        return await PeacockDemoProvider().generate_demo_response("Command R+", messages)

    async def stream_chat(self, messages: List[Dict[str, Any]], options: Optional[Dict[str, Any]] = None) -> AsyncGenerator[str, None]:
        streamed = False
        async for token in self._call_openrouter_stream(self.MODEL_SLUG, messages, settings.AI_PROVIDER_09_API_KEY):
            streamed = True
            yield token

        if not streamed:
            from backend.providers.provider_15 import PeacockDemoProvider
            async for token in PeacockDemoProvider().generate_demo_stream("Command R+", messages):
                yield token
