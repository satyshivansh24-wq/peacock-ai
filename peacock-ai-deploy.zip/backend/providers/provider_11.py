from typing import List, AsyncGenerator, Dict, Any, Optional
from backend.providers.base import BaseAIProvider
from backend.schemas.pydantic_schemas import AIModelCard
from backend.config import settings

class Grok2Provider(BaseAIProvider):
    MODEL_SLUG = "meta-llama/llama-3.1-8b-instruct"

    def get_metadata(self) -> AIModelCard:
        is_live = bool(self.get_api_key())
        return AIModelCard(
            id="grok_2",
            name="Grok 2",
            tagline="Real-time X Knowledge & Witty Conversationalist",
            provider="xAI",
            color_name="Orange",
            color_hex="#F97316",
            badge_bg="rgba(249, 115, 22, 0.2)",
            icon="zap",
            description="xAI's flagship conversational intelligence combining real-time data access with witty, direct reasoning.",
            speed_rating=5,
            capabilities=["Real-time Data", "Witty Dialogue", "Coding", "Reasoning"],
            supports_vision=True,
            supports_documents=True,
            supports_code=True,
            status="LIVE" if is_live else "DEMO",
            is_demo_fallback=not is_live
        )

    async def chat(self, messages: List[Dict[str, Any]], options: Optional[Dict[str, Any]] = None) -> str:
        res = await self._call_openrouter_chat(self.MODEL_SLUG, messages, settings.AI_PROVIDER_11_API_KEY)
        if res:
            return res
        from backend.providers.provider_15 import PeacockDemoProvider
        return await PeacockDemoProvider().generate_demo_response("Grok 2", messages)

    async def stream_chat(self, messages: List[Dict[str, Any]], options: Optional[Dict[str, Any]] = None) -> AsyncGenerator[str, None]:
        streamed = False
        async for token in self._call_openrouter_stream(self.MODEL_SLUG, messages, settings.AI_PROVIDER_11_API_KEY):
            streamed = True
            yield token

        if not streamed:
            from backend.providers.provider_15 import PeacockDemoProvider
            async for token in PeacockDemoProvider().generate_demo_stream("Grok 2", messages):
                yield token
