from typing import List, AsyncGenerator, Dict, Any, Optional
from backend.providers.base import BaseAIProvider
from backend.schemas.pydantic_schemas import AIModelCard
from backend.config import settings

class TogetherVisionProvider(BaseAIProvider):
    MODEL_SLUG = "google/gemini-2.5-flash"

    def get_metadata(self) -> AIModelCard:
        is_live = bool(self.get_api_key())
        return AIModelCard(
            id="together_vision",
            name="Together Vision",
            tagline="Multi-Modal Visual Intelligence & OCR",
            provider="Together AI",
            color_name="Pink",
            color_hex="#EC4899",
            badge_bg="rgba(236, 72, 153, 0.2)",
            icon="image",
            description="Open multi-modal vision engine capable of extracting diagram data, OCR text parsing, and visual reasoning.",
            speed_rating=4,
            capabilities=["Vision", "OCR", "Diagram Parsing", "Chat"],
            supports_vision=True,
            supports_documents=True,
            supports_code=True,
            status="LIVE" if is_live else "DEMO",
            is_demo_fallback=not is_live
        )

    async def chat(self, messages: List[Dict[str, Any]], options: Optional[Dict[str, Any]] = None) -> str:
        res = await self._call_openrouter_chat(self.MODEL_SLUG, messages, settings.AI_PROVIDER_13_API_KEY)
        if res:
            return res
        from backend.providers.provider_15 import PeacockDemoProvider
        return await PeacockDemoProvider().generate_demo_response("Together Vision", messages)

    async def stream_chat(self, messages: List[Dict[str, Any]], options: Optional[Dict[str, Any]] = None) -> AsyncGenerator[str, None]:
        streamed = False
        async for token in self._call_openrouter_stream(self.MODEL_SLUG, messages, settings.AI_PROVIDER_13_API_KEY):
            streamed = True
            yield token

        if not streamed:
            from backend.providers.provider_15 import PeacockDemoProvider
            async for token in PeacockDemoProvider().generate_demo_stream("Together Vision", messages):
                yield token
