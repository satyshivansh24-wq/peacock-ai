from typing import List, AsyncGenerator, Dict, Any, Optional
from backend.providers.base import BaseAIProvider
from backend.schemas.pydantic_schemas import AIModelCard
from backend.config import settings

class FireworksStreamProvider(BaseAIProvider):
    MODEL_SLUG = "meta-llama/llama-3.1-8b-instruct"

    def get_metadata(self) -> AIModelCard:
        is_live = bool(self.get_api_key())
        return AIModelCard(
            id="fireworks_stream",
            name="Fireworks Stream",
            tagline="Ultra Low Latency Streaming Inference Engine",
            provider="Fireworks AI",
            color_name="Purple",
            color_hex="#A855F7",
            badge_bg="rgba(168, 85, 247, 0.2)",
            icon="zap",
            description="Specialized high-speed token generation engine optimized for sub-100ms first token latency.",
            speed_rating=5,
            capabilities=["Ultra Fast Streaming", "Low Latency", "Chat", "Coding"],
            supports_vision=False,
            supports_documents=True,
            supports_code=True,
            status="LIVE" if is_live else "DEMO",
            is_demo_fallback=not is_live
        )

    async def chat(self, messages: List[Dict[str, Any]], options: Optional[Dict[str, Any]] = None) -> str:
        res = await self._call_openrouter_chat(self.MODEL_SLUG, messages, settings.AI_PROVIDER_14_API_KEY)
        if res:
            return res
        from backend.providers.provider_15 import PeacockDemoProvider
        return await PeacockDemoProvider().generate_demo_response("Fireworks Stream", messages)

    async def stream_chat(self, messages: List[Dict[str, Any]], options: Optional[Dict[str, Any]] = None) -> AsyncGenerator[str, None]:
        streamed = False
        async for token in self._call_openrouter_stream(self.MODEL_SLUG, messages, settings.AI_PROVIDER_14_API_KEY):
            streamed = True
            yield token

        if not streamed:
            from backend.providers.provider_15 import PeacockDemoProvider
            async for token in PeacockDemoProvider().generate_demo_stream("Fireworks Stream", messages):
                yield token
