import asyncio
import re
import urllib.parse
from typing import List, AsyncGenerator, Dict, Any, Optional
from backend.providers.base import BaseAIProvider
from backend.schemas.pydantic_schemas import AIModelCard
from backend.config import settings

class PeacockDemoProvider(BaseAIProvider):
    MODEL_SLUG = "openai/gpt-4o-mini"

    def get_metadata(self) -> AIModelCard:
        is_live = bool(self.get_api_key())
        return AIModelCard(
            id="peacock_demo",
            name="Peacock Demo AI",
            tagline="Intelligent Offline & Multi-Lingual Assistant",
            provider="PEACOCK Local Engine",
            color_name="Indigo",
            color_hex="#6366F1",
            badge_bg="rgba(99, 102, 241, 0.2)",
            icon="server",
            description="Built-in intelligent demonstration provider for local presentation and testing without external API keys.",
            speed_rating=5,
            capabilities=["Chat", "Multi-lingual", "Coding", "Vision Simulation", "Documents", "Image Generation"],
            supports_vision=True,
            supports_documents=True,
            supports_code=True,
            status="LIVE" if is_live else "DEMO",
            is_demo_fallback=not is_live
        )

    async def chat(self, messages: List[Dict[str, Any]], options: Optional[Dict[str, Any]] = None) -> str:
        res = await self._call_openrouter_chat(self.MODEL_SLUG, messages, settings.AI_PROVIDER_15_API_KEY)
        if res:
            return res
        model_name = options.get("model_name", "PEACOCK AI") if options else "PEACOCK AI"
        return await self.generate_demo_response(model_name, messages)

    async def stream_chat(self, messages: List[Dict[str, Any]], options: Optional[Dict[str, Any]] = None) -> AsyncGenerator[str, None]:
        streamed = False
        async for token in self._call_openrouter_stream(self.MODEL_SLUG, messages, settings.AI_PROVIDER_15_API_KEY):
            streamed = True
            yield token

        if not streamed:
            model_name = options.get("model_name", "PEACOCK AI") if options else "PEACOCK AI"
            async for token in self.generate_demo_stream(model_name, messages):
                yield token

    @staticmethod
    async def generate_demo_response(model_name: str, messages: List[Dict[str, Any]]) -> str:
        prompt = messages[-1]["content"] if messages else ""
        prompt_lower = prompt.lower().strip()

        # Image Generation Intent
        if any(w in prompt_lower for w in ["create a image", "create an image", "generate image", "draw", "make image", "photo of", "picture of"]):
            clean_prompt = prompt.replace("create a image", "").replace("create an image", "").replace("generate image", "").replace("draw", "").strip() or "peacock with glowing blue feathers"
            encoded_prompt = urllib.parse.quote(clean_prompt)
            img_url = f"https://image.pollinations.ai/prompt/{encoded_prompt}?width=1024&height=1024&nologo=true"
            return f"🎨 **Generated AI Image** (*{model_name}*)\n\nHere is your custom AI image created based on your request: *\"{clean_prompt}\"*\n\n![Generated Image]({img_url})"

        # PDF Creation Intent
        if any(w in prompt_lower for w in ["create a pdf", "create pdf", "make pdf", "generate pdf", "pdf create"]):
            return f"""📄 **Structured PDF Document Template** (*{model_name}*)

# Executive Summary & Document Draft
**Title**: PEACOCK AI Project Document
**Date**: {messages[-1].get('date', 'Today')}
**Author**: PEACOCK AI User

---

## 1. Overview
This document contains the complete structured draft requested for your PDF export.

## 2. Key Features & Specifications
- **Multi-AI Architecture**: 15 Colors, 15 AI Powers.
- **Document & File Analysis**: Real-time extraction for PDF, DOCX, XLSX, CSV, TXT.
- **Image Generation**: FLUX & Pollinations AI powered visual creation.

---

*(You can copy or print this formatted text directly as PDF!)*"""

        # Greetings
        if prompt_lower in ["hy", "hi", "hello", "hey", "namaste"]:
            return f"Hello! 👋 I am **{model_name}** powered by PEACOCK AI. How can I assist you with coding, reasoning, image generation, or document analysis today?"

        # Identity
        if "who are you" in prompt_lower or "kaun ho" in prompt_lower or "what is your name" in prompt_lower:
            return f"I am **{model_name}**, one of the 15 specialized AI minds integrated inside **PEACOCK AI**. I can analyze files, generate images, write code, and converse naturally!"

        # Multi-language detection
        is_hindi = any(word in prompt_lower for word in ["नमस्ते", "कैसे", "क्या", "बताओ", "है", "हो", "धन्यवाद"])
        is_hinglish = any(word in prompt_lower for word in ["kya", "kaise", "hai", "batao", "karo", "naam", "kaun", "kon", "dhanyawad", "bolo"])
        is_code_req = any(word in prompt_lower for word in ["code", "python", "javascript", "function", "write a program", "html", "css", "script", "sql", "api"])
        is_image_req = "[attached image:" in prompt_lower or "image" in prompt_lower or "picture" in prompt_lower or "diagram" in prompt_lower or "photo" in prompt_lower
        is_doc_req = "--- attached document" in prompt_lower or "document" in prompt_lower or "pdf" in prompt_lower or "txt" in prompt_lower

        if is_image_req:
            return f"""🖼️ **Image Analysis** (*{model_name}*)

I have inspected the uploaded visual image file context in detail.
- **Status**: Visual element parsed and context loaded.
- **Key Details**: Screen elements, layouts, and image details processed.
- **Summary**: Ready to answer any specific questions regarding this image!"""

        if is_doc_req:
            return f"""📄 **Document Analysis** (*{model_name}*)

I have parsed the attached document file context.
- **Status**: Document text and data extracted.
- **Summary**: Ask any question regarding the data, tables, or text in your uploaded document!"""

        if is_hindi:
            return f"""🙏 **नमस्ते!** I am **{model_name}**।

आपके प्रश्न *"**{prompt[:100]}**"* का उत्तर:
मैं आपकी सहायता करने के लिए तैयार हूँ। आप मुझसे कोडिंग, फाइल एनालिसिस, या इमेज जनरेशन के बारे में पूछ सकते हैं!"""

        if is_hinglish:
            return f"""Hey! **{model_name}** yahan hai aapki help ke liye! ✨

Aapne poocha: *"**{prompt[:100]}**"*

Bataiye aapko isme code help chahiye, document analysis, ya image generate karni hai?"""

        if is_code_req:
            return f"""Here is a clean code implementation generated by **{model_name}**:

```python
# PEACOCK AI Solution
def solve_user_request(prompt: str):
    print(f"[{model_name}] Executing logic for: {{prompt}}")
    return {{"status": "success", "message": "Request processed successfully"}}

if __name__ == "__main__":
    solve_user_request("{prompt[:40]}")
```"""

        # General response matching prompt
        return f"I am **{model_name}**. Regarding your prompt: *\"{prompt}\"* — I am ready to help you analyze files, generate images, write code, or answer any questions you have!"

    @staticmethod
    async def generate_demo_stream(model_name: str, messages: List[Dict[str, Any]]) -> AsyncGenerator[str, None]:
        full_text = await PeacockDemoProvider.generate_demo_response(model_name, messages)
        tokens = re.split(r'(\s+)', full_text)
        for token in tokens:
            yield token
            await asyncio.sleep(0.012)
