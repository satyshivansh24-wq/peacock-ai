from typing import Dict, List, AsyncGenerator, Any, Optional
from backend.providers.base import BaseAIProvider
from backend.providers.provider_01 import PeacockUltraProvider
from backend.providers.provider_02 import GPT4oMindProvider
from backend.providers.provider_03 import ClaudeSonnetProvider
from backend.providers.provider_04 import GeminiFlashProvider
from backend.providers.provider_05 import DeepSeekR1Provider
from backend.providers.provider_06 import LlamaProvider
from backend.providers.provider_07 import MistralLargeProvider
from backend.providers.provider_08 import QwenMaxProvider
from backend.providers.provider_09 import CommandRPlusProvider
from backend.providers.provider_10 import PerplexitySonarProvider
from backend.providers.provider_11 import Grok2Provider
from backend.providers.provider_12 import PhindCodeProvider
from backend.providers.provider_13 import TogetherVisionProvider
from backend.providers.provider_14 import FireworksStreamProvider
from backend.providers.provider_15 import PeacockDemoProvider
from backend.schemas.pydantic_schemas import AIModelCard, ProviderStatus

class ProviderManager:
    def __init__(self):
        self._providers: Dict[str, BaseAIProvider] = {
            "peacock_ultra": PeacockUltraProvider(),
            "gpt4o_mind": GPT4oMindProvider(),
            "claude_35_sonnet": ClaudeSonnetProvider(),
            "gemini_15_flash": GeminiFlashProvider(),
            "deepseek_r1": DeepSeekR1Provider(),
            "llama_33_70b": LlamaProvider(),
            "mistral_large": MistralLargeProvider(),
            "qwen_25_max": QwenMaxProvider(),
            "command_r_plus": CommandRPlusProvider(),
            "perplexity_sonar": PerplexitySonarProvider(),
            "grok_2": Grok2Provider(),
            "phind_code_pro": PhindCodeProvider(),
            "together_vision": TogetherVisionProvider(),
            "fireworks_stream": FireworksStreamProvider(),
            "peacock_demo": PeacockDemoProvider(),
        }

    def get_provider(self, model_id: str) -> BaseAIProvider:
        return self._providers.get(model_id, self._providers["peacock_ultra"])

    def get_all_models(self) -> List[AIModelCard]:
        return [p.get_metadata() for p in self._providers.values()]

    def get_provider_statuses(self) -> List[ProviderStatus]:
        statuses = []
        for model_id, provider in self._providers.items():
            meta = provider.get_metadata()
            status_text = "CONNECTED (LIVE)" if provider.is_configured() else "NOT CONFIGURED (DEMO)"
            if model_id == "peacock_demo":
                status_text = "LOCAL DEMO ENGINE"
            statuses.append(ProviderStatus(
                model_id=model_id,
                name=meta.name,
                color_hex=meta.color_hex,
                status=status_text,
                capabilities=meta.capabilities
            ))
        return statuses

    async def chat(self, model_id: str, messages: List[Dict[str, Any]], options: Optional[Dict[str, Any]] = None) -> str:
        provider = self.get_provider(model_id)
        model_name = provider.get_metadata().name
        opts = options or {}
        opts["model_name"] = model_name
        
        try:
            return await provider.chat(messages, opts)
        except Exception as e:
            # Safe Fallback to Demo Engine
            return await PeacockDemoProvider().generate_demo_response(model_name, messages)

    async def stream_chat(self, model_id: str, messages: List[Dict[str, Any]], options: Optional[Dict[str, Any]] = None) -> AsyncGenerator[str, None]:
        provider = self.get_provider(model_id)
        model_name = provider.get_metadata().name
        opts = options or {}
        opts["model_name"] = model_name

        try:
            async for token in provider.stream_chat(messages, opts):
                yield token
        except Exception:
            async for token in PeacockDemoProvider().generate_demo_stream(model_name, messages):
                yield token

provider_manager = ProviderManager()
