import datetime
from pydantic import BaseModel, EmailStr, Field, ConfigDict
from typing import List, Optional, Any

# User Schemas
class UserRegister(BaseModel):
    full_name: str = Field(..., min_length=2, max_length=100)
    email: EmailStr
    password: str = Field(..., min_length=6)

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class UserResponse(BaseModel):
    id: int
    email: EmailStr
    full_name: str
    created_at: datetime.datetime

    model_config = ConfigDict(from_attributes=True)

class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserResponse

# Conversation Schemas
class ConversationCreate(BaseModel):
    title: Optional[str] = "New Chat"
    model_id: Optional[str] = "peacock_ultra"

class ConversationUpdate(BaseModel):
    title: Optional[str] = None
    is_favorite: Optional[bool] = None
    model_id: Optional[str] = None

class MessageAttachment(BaseModel):
    id: str
    filename: str
    file_type: str
    file_size: int
    extracted_text: Optional[str] = None

class MessageCreate(BaseModel):
    conversation_id: str
    content: str
    model_id: Optional[str] = "peacock_ultra"
    file_attachments: Optional[List[dict]] = []

class MessageResponse(BaseModel):
    id: str
    conversation_id: str
    role: str
    content: str
    model_id: Optional[str]
    file_attachments: Optional[List[dict]] = []
    feedback: Optional[str] = None
    created_at: datetime.datetime

    model_config = ConfigDict(from_attributes=True)

class ConversationResponse(BaseModel):
    id: str
    user_id: int
    title: str
    model_id: str
    is_favorite: bool
    created_at: datetime.datetime
    updated_at: datetime.datetime
    messages: Optional[List[MessageResponse]] = []

    model_config = ConfigDict(from_attributes=True)

class FeedbackUpdate(BaseModel):
    feedback: str  # 'like', 'dislike', 'none'

# Settings Schemas
class UserSettingsUpdate(BaseModel):
    theme: Optional[str] = "dark"
    default_model: Optional[str] = "peacock_ultra"
    response_language: Optional[str] = "Auto (Match Prompt)"
    enter_to_send: Optional[bool] = True
    streaming_enabled: Optional[bool] = True

class UserSettingsResponse(BaseModel):
    theme: str
    default_model: str
    response_language: str
    enter_to_send: bool
    streaming_enabled: bool

    model_config = ConfigDict(from_attributes=True)

# 15 AI Model / Provider Info Schemas
class AIModelCard(BaseModel):
    id: str
    name: str
    tagline: str
    provider: str
    color_name: str
    color_hex: str
    badge_bg: str
    icon: str
    description: str
    speed_rating: int
    capabilities: List[str]
    supports_vision: bool
    supports_documents: bool
    supports_code: bool
    status: str
    is_demo_fallback: bool

class ProviderStatus(BaseModel):
    model_id: str
    name: str
    color_hex: str
    status: str
    capabilities: List[str]
