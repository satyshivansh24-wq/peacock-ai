import smtplib
import logging
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from backend.config import settings

logger = logging.getLogger(__name__)

async def send_password_reset_email(to_email: str, otp_code: str):
    """
    Sends a Password Reset verification email to the user with a 6-digit OTP code.
    If SMTP credentials are provided in .env, sends via live SMTP.
    Otherwise logs the code cleanly for development & demo.
    """
    subject = "🦚 PEACOCK AI — Password Reset Verification Code"
    
    html_content = f"""
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <style>
        body {{ font-family: 'Plus Jakarta Sans', Arial, sans-serif; background-color: #0B0F19; color: #FFFFFF; padding: 20px; }}
        .card {{ background: #131B2E; border: 1px solid #1E293B; border-radius: 12px; padding: 30px; max-width: 500px; margin: 0 auto; box-shadow: 0 10px 30px rgba(0,0,0,0.5); }}
        .logo {{ font-size: 24px; font-weight: 800; color: #38BDF8; margin-bottom: 10px; }}
        .code {{ font-size: 32px; font-weight: 800; letter-spacing: 6px; color: #38BDF8; background: #0F172A; padding: 14px; text-align: center; border-radius: 8px; margin: 20px 0; border: 1px dashed #38BDF8; }}
        .footer {{ font-size: 12px; color: #64748B; margin-top: 20px; text-align: center; }}
      </style>
    </head>
    <body>
      <div class="card">
        <div class="logo">🦚 PEACOCK AI</div>
        <h3>Password Reset Request</h3>
        <p>You requested to reset your password for your PEACOCK AI account (<strong>{to_email}</strong>).</p>
        <p>Your 6-digit Password Reset Verification Code is:</p>
        <div class="code">{otp_code}</div>
        <p>Enter this verification code on the password reset screen to update your password in Supabase PostgreSQL database.</p>
        <div class="footer">If you did not request a password reset, please ignore this email.</div>
      </div>
    </body>
    </html>
    """

    if settings.SMTP_USER and settings.SMTP_PASSWORD:
        try:
            msg = MIMEMultipart("alternative")
            msg["Subject"] = subject
            msg["From"] = settings.EMAIL_FROM
            msg["To"] = to_email
            msg.attach(MIMEText(html_content, "html"))

            with smtplib.SMTP(settings.SMTP_HOST, settings.SMTP_PORT) as server:
                server.starttls()
                server.login(settings.SMTP_USER, settings.SMTP_PASSWORD)
                server.sendmail(settings.EMAIL_FROM, [to_email], msg.as_string())
            logger.info(f"Password reset email sent successfully to {to_email}")
            return True
        except Exception as e:
            logger.error(f"Failed to send password reset email via SMTP: {e}")
            return False
    else:
        logger.info(f"[PEACOCK AI EMAIL SERVICE] Verification code {otp_code} generated for {to_email}")
        return True
