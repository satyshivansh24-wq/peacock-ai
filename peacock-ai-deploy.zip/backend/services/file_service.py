import os
import uuid
import json
import datetime
from fastapi import UploadFile, HTTPException
from backend.config import settings

ALLOWED_EXTENSIONS = {
    "txt", "md", "csv", "json", "pdf", "docx", "xlsx",
    "png", "jpg", "jpeg", "webp", "gif", "svg"
}

MAX_FILE_SIZE_BYTES = 25 * 1024 * 1024  # 25 MB max

def validate_file(file: UploadFile):
    filename = file.filename or "file"
    ext = filename.split(".")[-1].lower() if "." in filename else ""
    
    if ext not in ALLOWED_EXTENSIONS:
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported file type (.{ext}). Allowed formats: PDF, DOCX, TXT, CSV, XLSX, JSON, Images."
        )
    return ext

async def process_and_save_file(file: UploadFile, conversation_id: str = None) -> dict:
    ext = validate_file(file)
    content = await file.read()
    
    if len(content) > MAX_FILE_SIZE_BYTES:
        raise HTTPException(
            status_code=400,
            detail="File size exceeds maximum allowed limit of 25MB."
        )
    
    file_id = str(uuid.uuid4())
    safe_filename = f"{file_id}_{file.filename}"
    file_path = os.path.join(settings.UPLOAD_DIR, safe_filename)
    
    with open(file_path, "wb") as f:
        f.write(content)
    
    extracted_text = extract_text_from_file(file_path, ext, content)
    
    file_type = "image" if ext in ["png", "jpg", "jpeg", "webp", "gif", "svg"] else "document"
    
    return {
        "id": file_id,
        "filename": file.filename,
        "file_path": file_path,
        "file_type": file_type,
        "file_size": len(content),
        "extracted_text": extracted_text
    }

def extract_text_from_file(file_path: str, ext: str, raw_bytes: bytes) -> str:
    try:
        if ext in ["txt", "md", "json", "csv"]:
            return raw_bytes.decode("utf-8", errors="ignore")[:20000]
        
        elif ext == "pdf":
            try:
                import pypdf
                reader = pypdf.PdfReader(file_path)
                text = []
                for page in reader.pages[:20]:  # limit to first 20 pages
                    t = page.extract_text()
                    if t: text.append(t)
                return "\n".join(text)[:25000]
            except Exception as e:
                return f"[PDF document attached: {os.path.basename(file_path)}]"
        
        elif ext == "docx":
            try:
                import docx
                doc = docx.Document(file_path)
                text = [p.text for p in doc.paragraphs if p.text]
                return "\n".join(text)[:25000]
            except Exception as e:
                return f"[Word document attached: {os.path.basename(file_path)}]"
                
        elif ext == "xlsx":
            try:
                import openpyxl
                wb = openpyxl.load_workbook(file_path, read_only=True)
                lines = []
                for sheet in wb.worksheets[:5]:
                    lines.append(f"--- Sheet: {sheet.title} ---")
                    for row in list(sheet.iter_rows(values_only=True))[:100]:
                        row_str = ", ".join([str(cell) for cell in row if cell is not None])
                        if row_str: lines.append(row_str)
                return "\n".join(lines)[:25000]
            except Exception as e:
                return f"[Excel spreadsheet attached: {os.path.basename(file_path)}]"
                
        elif ext in ["png", "jpg", "jpeg", "webp", "gif", "svg"]:
            import base64
            b64 = base64.b64encode(raw_bytes).decode("utf-8")
            return f"data:image/{ext};base64,{b64}"
            
    except Exception as e:
        return f"[File content unreadable: {str(e)}]"
        
    return ""
