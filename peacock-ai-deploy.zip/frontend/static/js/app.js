/* PEACOCK AI — Main Application Controller */

const App = {
  currentView: 'welcome',

  init() {
    console.log("🦚 PEACOCK AI — Commercial Multi-AI Workspace Initialized");

    // Initialize Canvas Particles
    new PeacockParticleSystem('canvas-bg');

    // Initialize Submodules
    AuthModule.init();
    ModelsModule.init();
    ChatModule.init();
    UploadModule.init();
    VoiceModule.init();
    SettingsModule.init();

    // Logo-Only Cinematic Splash Timing (2.0 seconds)
    setTimeout(() => {
      const splash = document.getElementById('splash-view');
      if (splash) {
        splash.classList.add('fade-out');
        setTimeout(() => {
          splash.remove();
          // Persistent Session: If logged in, go straight to workspace; else welcome page
          if (AuthModule.token && AuthModule.currentUser) {
            this.showView('dashboard');
          } else {
            this.showView('welcome');
          }
        }, 600);
      }
    }, 2000);

    this.bindEvents();
  },

  bindEvents() {
    // Show / Hide Password Eye Toggle Handlers
    document.querySelectorAll('.btn-toggle-pwd').forEach(btn => {
      btn.addEventListener('click', (e) => {
        if (e) {
          e.preventDefault();
          e.stopPropagation();
        }
        const targetId = btn.getAttribute('data-target');
        const input = document.getElementById(targetId);
        if (!input) return;

        const openIcon = btn.querySelector('.eye-open');
        const closedIcon = btn.querySelector('.eye-closed');

        if (input.type === 'password') {
          input.type = 'text';
          if (openIcon) openIcon.style.display = 'none';
          if (closedIcon) closedIcon.style.display = 'block';
        } else {
          input.type = 'password';
          if (openIcon) openIcon.style.display = 'block';
          if (closedIcon) closedIcon.style.display = 'none';
        }
      });
    });

    // Welcome View Action Button (Centred Sign In)
    const btnSignIn = document.getElementById('btn-welcome-sign-in');

    if (btnSignIn) {
      btnSignIn.addEventListener('click', () => {
        const modal = document.getElementById('auth-modal-overlay');
        if (modal) modal.classList.add('active');
      });
    }

    const btnCloseAuthModal = document.getElementById('btn-close-auth-modal');
    if (btnCloseAuthModal) {
      btnCloseAuthModal.addEventListener('click', () => {
        const modal = document.getElementById('auth-modal-overlay');
        if (modal) modal.classList.remove('active');
      });
    }

    // Forgot Password Trigger Fallback
    const btnOpenForgot = document.getElementById('btn-open-forgot-modal');
    if (btnOpenForgot) {
      btnOpenForgot.addEventListener('click', (e) => {
        if (e) {
          e.preventDefault();
          e.stopPropagation();
        }
        const authModal = document.getElementById('auth-modal-overlay');
        const forgotModal = document.getElementById('forgot-modal-overlay');
        const errorEl = document.getElementById('forgot-error-msg');
        const successEl = document.getElementById('forgot-success-msg');
        const reqForm = document.getElementById('forgot-request-form');
        const resetForm = document.getElementById('forgot-reset-form');

        if (errorEl) errorEl.style.display = 'none';
        if (successEl) successEl.style.display = 'none';
        if (reqForm) reqForm.style.display = 'block';
        if (resetForm) resetForm.style.display = 'none';

        if (authModal) authModal.classList.remove('active');
        if (forgotModal) forgotModal.classList.add('active');
      });
    }

    const btnCloseForgotModal = document.getElementById('btn-close-forgot-modal');
    if (btnCloseForgotModal) {
      btnCloseForgotModal.addEventListener('click', () => {
        const forgotModal = document.getElementById('forgot-modal-overlay');
        if (forgotModal) forgotModal.classList.remove('active');
      });
    }

    // Auth Tabs Switcher
    const tabLogin = document.getElementById('tab-btn-login');
    const tabRegister = document.getElementById('tab-btn-register');
    const loginForm = document.getElementById('login-form');
    const regForm = document.getElementById('register-form');

    if (tabLogin && tabRegister) {
      tabLogin.addEventListener('click', () => {
        tabLogin.classList.add('active');
        tabRegister.classList.remove('active');
        loginForm.style.display = 'block';
        regForm.style.display = 'none';
      });

      tabRegister.addEventListener('click', () => {
        tabRegister.classList.add('active');
        tabLogin.classList.remove('active');
        regForm.style.display = 'block';
        loginForm.style.display = 'none';
      });
    }

    // Sidebar Toggle for Desktop & Mobile
    const sidebarToggle = document.getElementById('btn-toggle-sidebar');
    const sidebar = document.getElementById('sidebar');

    if (sidebarToggle && sidebar) {
      sidebarToggle.addEventListener('click', () => {
        if (window.innerWidth <= 768) {
          sidebar.classList.toggle('mobile-open');
        } else {
          sidebar.classList.toggle('collapsed');
        }
      });
    }

    // User Profile Card Menu Toggle
    const userProfileBtn = document.getElementById('btn-user-profile');
    const userMenuCard = document.getElementById('user-account-menu-card');

    if (userProfileBtn && userMenuCard) {
      userProfileBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        const isOpen = userMenuCard.style.display === 'flex';
        userMenuCard.style.display = isOpen ? 'none' : 'flex';
      });

      document.addEventListener('click', (e) => {
        if (!userMenuCard.contains(e.target) && !userProfileBtn.contains(e.target)) {
          userMenuCard.style.display = 'none';
        }
      });
    }

    // User Menu Items
    const menuSettings = document.getElementById('user-menu-item-settings');
    const menuSwitch = document.getElementById('user-menu-item-switch');
    const menuLogout = document.getElementById('user-menu-item-logout');

    if (menuSettings) {
      menuSettings.addEventListener('click', () => {
        if (userMenuCard) userMenuCard.style.display = 'none';
        const modal = document.getElementById('settings-modal-overlay');
        if (modal) modal.classList.add('active');
      });
    }

    if (menuSwitch) {
      menuSwitch.addEventListener('click', () => {
        if (userMenuCard) userMenuCard.style.display = 'none';
        const modal = document.getElementById('auth-modal-overlay');
        if (modal) modal.classList.add('active');
      });
    }

    if (menuLogout) {
      menuLogout.addEventListener('click', () => {
        if (userMenuCard) userMenuCard.style.display = 'none';
        AuthModule.logout();
      });
    }
  },

  showConfirmCard(options) {
    const modal = document.getElementById('confirm-modal-overlay');
    const iconEl = document.getElementById('confirm-modal-icon');
    const titleEl = document.getElementById('confirm-modal-title');
    const descEl = document.getElementById('confirm-modal-desc');
    const inputWrap = document.getElementById('confirm-input-wrap');
    const inputField = document.getElementById('confirm-input-field');
    const btnCancel = document.getElementById('btn-confirm-cancel');
    const btnAccept = document.getElementById('btn-confirm-accept');

    if (!modal) return;

    if (iconEl) {
      if (typeof options.icon === 'string' && options.icon.startsWith('<svg')) {
        iconEl.innerHTML = options.icon;
      } else if (options.icon === '⚠️' || !options.icon) {
        iconEl.innerHTML = `<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#F59E0B" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>`;
      } else {
        iconEl.textContent = options.icon;
      }
    }
    if (titleEl) titleEl.textContent = options.title || 'Permission Required';
    if (descEl) descEl.textContent = options.desc || 'Are you sure you want to proceed?';

    if (options.hasInput) {
      if (inputWrap) inputWrap.style.display = 'block';
      if (inputField) {
        inputField.value = options.defaultValue || '';
        inputField.placeholder = options.inputPlaceholder || 'Enter value...';
      }
    } else {
      if (inputWrap) inputWrap.style.display = 'none';
    }

    if (btnAccept) {
      btnAccept.textContent = options.confirmText || 'Confirm';
      if (options.isDanger) {
        btnAccept.style.background = 'linear-gradient(135deg, #DC2626 0%, #EF4444 100%)';
        btnAccept.style.borderColor = '#EF4444';
      } else {
        btnAccept.style.background = 'var(--btn-peacock-gradient)';
        btnAccept.style.borderColor = 'var(--btn-peacock-blue)';
      }
    }

    const closeModal = () => {
      modal.classList.remove('active');
    };

    const cleanup = () => {
      closeModal();
      const newAccept = btnAccept.cloneNode(true);
      const newCancel = btnCancel.cloneNode(true);
      const closeBtn = document.getElementById('btn-close-confirm-modal');

      btnAccept.replaceWith(newAccept);
      btnCancel.replaceWith(newCancel);
      if (closeBtn) closeBtn.replaceWith(closeBtn.cloneNode(true));
    };

    const handleAccept = () => {
      const val = options.hasInput ? inputField.value.trim() : true;
      cleanup();
      if (options.onConfirm) options.onConfirm(val);
    };

    const handleCancel = () => {
      cleanup();
      if (options.onCancel) options.onCancel();
    };

    modal.classList.add('active');

    setTimeout(() => {
      document.getElementById('btn-confirm-accept').addEventListener('click', handleAccept);
      document.getElementById('btn-confirm-cancel').addEventListener('click', handleCancel);
      const closeBtn = document.getElementById('btn-close-confirm-modal');
      if (closeBtn) closeBtn.addEventListener('click', handleCancel);
      if (options.hasInput && inputField) inputField.focus();
    }, 50);
  },

  showView(viewName) {
    this.currentView = viewName;
    const welcomeView = document.getElementById('welcome-view');
    const dashboardView = document.getElementById('dashboard-view');

    if (viewName === 'dashboard') {
      if (welcomeView) welcomeView.style.display = 'none';
      if (dashboardView) dashboardView.style.display = 'flex';
      ChatModule.loadConversations();
    } else {
      if (dashboardView) dashboardView.style.display = 'none';
      if (welcomeView) welcomeView.style.display = 'flex';
    }
  }
};

document.addEventListener('DOMContentLoaded', () => App.init());
