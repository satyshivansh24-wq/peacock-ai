/* PEACOCK AI — Authentication & Secure Email Password Reset Module */

const AuthModule = {
  currentUser: JSON.parse(localStorage.getItem('peacock_user') || 'null'),
  token: localStorage.getItem('peacock_token') || null,
  forgotEmail: null,

  init() {
    this.bindEvents();
    if (this.token) {
      this.checkAuthStatus();
    }
  },

  bindEvents() {
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');
    const btnOpenForgotModal = document.getElementById('btn-open-forgot-modal');
    const btnCloseForgotModal = document.getElementById('btn-close-forgot-modal');
    const forgotRequestForm = document.getElementById('forgot-request-form');
    const forgotResetForm = document.getElementById('forgot-reset-form');

    if (loginForm) {
      loginForm.addEventListener('submit', (e) => this.handleLogin(e));
    }
    if (registerForm) {
      registerForm.addEventListener('submit', (e) => this.handleRegister(e));
    }

    // Forgot Password Modal Binding
    if (btnOpenForgotModal) {
      btnOpenForgotModal.addEventListener('click', (e) => {
        if (e) {
          e.preventDefault();
          e.stopPropagation();
        }
        const authModal = document.getElementById('auth-modal-overlay');
        const forgotModal = document.getElementById('forgot-modal-overlay');
        const errorEl = document.getElementById('forgot-error-msg');
        const successEl = document.getElementById('forgot-success-msg');
        const reqForm = document.getElementById('forgot-request-form');
        const resetForm = document.getElementById('forgot-reset-form');

        if (errorEl) errorEl.style.display = 'none';
        if (successEl) successEl.style.display = 'none';
        if (reqForm) reqForm.style.display = 'block';
        if (resetForm) resetForm.style.display = 'none';

        if (authModal) authModal.classList.remove('active');
        if (forgotModal) forgotModal.classList.add('active');
      });
    }
    if (btnCloseForgotModal) {
      btnCloseForgotModal.addEventListener('click', () => {
        const forgotModal = document.getElementById('forgot-modal-overlay');
        if (forgotModal) forgotModal.classList.remove('active');
      });
    }

    if (forgotRequestForm) {
      forgotRequestForm.addEventListener('submit', (e) => this.handleForgotRequest(e));
    }
    if (forgotResetForm) {
      forgotResetForm.addEventListener('submit', (e) => this.handleForgotReset(e));
    }
  },

  async handleForgotRequest(e) {
    e.preventDefault();
    const email = document.getElementById('forgot-email').value.trim();
    const errorEl = document.getElementById('forgot-error-msg');
    const successEl = document.getElementById('forgot-success-msg');
    const reqForm = document.getElementById('forgot-request-form');
    const resetForm = document.getElementById('forgot-reset-form');

    if (errorEl) errorEl.style.display = 'none';
    if (successEl) successEl.style.display = 'none';

    try {
      const res = await fetch('/api/auth/forgot-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.detail || 'Failed to process request');
      }

      this.forgotEmail = email;

      if (successEl) {
        successEl.innerHTML = `📩 <strong>Verification Code Sent!</strong><br>Check your email inbox (<strong>${email}</strong>) and enter the 6-digit code below:`;
        successEl.style.display = 'block';
      }

      if (reqForm) reqForm.style.display = 'none';
      if (resetForm) resetForm.style.display = 'block';

      const otpInput = document.getElementById('reset-otp-code');
      if (otpInput) {
        otpInput.value = '';
        otpInput.focus();
      }
    } catch (err) {
      if (errorEl) {
        errorEl.textContent = err.message;
        errorEl.style.display = 'block';
      }
    }
  },

  async handleForgotReset(e) {
    e.preventDefault();
    const otpCode = document.getElementById('reset-otp-code').value.trim();
    const newPassword = document.getElementById('reset-new-password').value;
    const errorEl = document.getElementById('forgot-error-msg');

    if (errorEl) errorEl.style.display = 'none';

    try {
      const res = await fetch('/api/auth/reset-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: this.forgotEmail,
          otp_code: otpCode,
          new_password: newPassword
        })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.detail || 'Password reset failed');
      }

      this.saveAuth(data.access_token, data.user);

      const forgotModal = document.getElementById('forgot-modal-overlay');
      if (forgotModal) forgotModal.classList.remove('active');

      App.showView('dashboard');
    } catch (err) {
      if (errorEl) {
        errorEl.textContent = err.message;
        errorEl.style.display = 'block';
      }
    }
  },

  async handleLogin(e) {
    e.preventDefault();
    const email = document.getElementById('login-email').value.trim();
    const password = document.getElementById('login-password').value;
    const errorEl = document.getElementById('auth-error-msg');
    
    if (errorEl) errorEl.style.display = 'none';

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.detail || 'Login failed');
      }

      this.saveAuth(data.access_token, data.user);
      const modal = document.getElementById('auth-modal-overlay');
      if (modal) modal.classList.remove('active');
      
      App.showView('dashboard');
      
      if (ChatModule.pendingPrompt) {
        const inputEl = document.getElementById('composer-textarea');
        if (inputEl) inputEl.value = ChatModule.pendingPrompt;
        ChatModule.pendingPrompt = null;
        setTimeout(() => ChatModule.sendMessage(), 300);
      }
    } catch (err) {
      if (errorEl) {
        errorEl.textContent = err.message;
        errorEl.style.display = 'block';
      }
    }
  },

  async handleRegister(e) {
    e.preventDefault();
    const fullName = document.getElementById('reg-name').value.trim();
    const email = document.getElementById('reg-email').value.trim();
    const password = document.getElementById('reg-password').value;
    const confirmPassword = document.getElementById('reg-confirm').value;
    const errorEl = document.getElementById('auth-error-msg');

    if (errorEl) errorEl.style.display = 'none';

    if (password !== confirmPassword) {
      if (errorEl) {
        errorEl.textContent = "Passwords do not match.";
        errorEl.style.display = 'block';
      }
      return;
    }

    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ full_name: fullName, email, password })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.detail || 'Registration failed');
      }

      this.saveAuth(data.access_token, data.user);
      const modal = document.getElementById('auth-modal-overlay');
      if (modal) modal.classList.remove('active');

      App.showView('dashboard');

      if (ChatModule.pendingPrompt) {
        const inputEl = document.getElementById('composer-textarea');
        if (inputEl) inputEl.value = ChatModule.pendingPrompt;
        ChatModule.pendingPrompt = null;
        setTimeout(() => ChatModule.sendMessage(), 300);
      }
    } catch (err) {
      if (errorEl) {
        errorEl.textContent = err.message;
        errorEl.style.display = 'block';
      }
    }
  },

  saveAuth(token, user) {
    this.token = token;
    this.currentUser = user;
    localStorage.setItem('peacock_token', token);
    localStorage.setItem('peacock_user', JSON.stringify(user));
    this.updateUserUI();
  },

  async checkAuthStatus() {
    try {
      const res = await fetch('/api/auth/me', {
        headers: { 'Authorization': `Bearer ${this.token}` }
      });
      if (res.ok) {
        this.currentUser = await res.json();
        localStorage.setItem('peacock_user', JSON.stringify(this.currentUser));
        this.updateUserUI();
      } else {
        this.token = null;
        this.currentUser = null;
        localStorage.removeItem('peacock_token');
        localStorage.removeItem('peacock_user');
      }
    } catch (err) {}
  },

  updateUserUI() {
    const nameEl = document.getElementById('user-display-name');
    const avatarEl = document.getElementById('user-avatar-initials');
    const menuNameEl = document.getElementById('user-menu-name');
    const menuEmailEl = document.getElementById('user-menu-email');
    const menuAvatarEl = document.getElementById('user-menu-avatar');

    if (this.currentUser) {
      if (nameEl) nameEl.textContent = this.currentUser.full_name;
      if (avatarEl) avatarEl.textContent = this.currentUser.full_name.charAt(0).toUpperCase();
      if (menuNameEl) menuNameEl.textContent = this.currentUser.full_name;
      if (menuEmailEl) menuEmailEl.textContent = this.currentUser.email;
      if (menuAvatarEl) menuAvatarEl.textContent = this.currentUser.full_name.charAt(0).toUpperCase();
    } else {
      if (nameEl) nameEl.textContent = "Guest User";
      if (avatarEl) avatarEl.textContent = "G";
      if (menuNameEl) menuNameEl.textContent = "Guest User";
      if (menuEmailEl) menuEmailEl.textContent = "guest@peacock.ai";
      if (menuAvatarEl) menuAvatarEl.textContent = "G";
    }
  },

  logout() {
    App.showConfirmCard({
      icon: `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#EF4444" stroke-width="2.2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>`,
      title: "Log Out Permission",
      desc: "Are you sure you want to log out of PEACOCK AI?",
      confirmText: "Log Out",
      isDanger: true,
      onConfirm: () => {
        this.token = null;
        this.currentUser = null;
        localStorage.removeItem('peacock_token');
        localStorage.removeItem('peacock_user');
        this.updateUserUI();
        
        fetch('/api/auth/logout', { method: 'POST' }).catch(() => {});
        App.showView('welcome');
      }
    });
  }
};
