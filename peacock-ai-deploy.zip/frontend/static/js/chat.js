/* PEACOCK AI — Chat & Streaming Workspace Module */

const ChatModule = {
  currentConversationId: null,
  activeModelId: 'peacock_ultra',
  isGenerating: false,
  pendingPrompt: null,

  init() {
    this.bindEvents();
  },

  bindEvents() {
    const sendBtn = document.getElementById('btn-send-msg');
    const inputEl = document.getElementById('composer-textarea');
    const newChatBtn = document.getElementById('btn-new-chat');

    if (sendBtn) {
      sendBtn.addEventListener('click', () => this.sendMessage());
    }

    if (inputEl) {
      inputEl.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
          const enterToSend = SettingsModule.settings.enter_to_send ?? true;
          if (enterToSend) {
            e.preventDefault();
            this.sendMessage();
          }
        }
      });
    }

    if (newChatBtn) {
      newChatBtn.addEventListener('click', () => this.startNewConversation());
    }
  },

  async loadConversations() {
    if (!AuthModule.token) {
      this.clearMessagesContainer();
      return;
    }
    try {
      const res = await fetch('/api/conversations', {
        headers: { 'Authorization': `Bearer ${AuthModule.token}` }
      });
      if (!res.ok) return;

      const convs = await res.json();
      this.renderConversationList(convs);

      if (convs.length > 0 && !this.currentConversationId) {
        this.selectConversation(convs[0].id);
      } else if (convs.length === 0) {
        this.startNewConversation();
      }
    } catch (e) {}
  },

  renderConversationList(conversations) {
    const listEl = document.getElementById('chat-history-list');
    if (!listEl) return;

    listEl.innerHTML = '';

    conversations.forEach(c => {
      const itemWrap = document.createElement('div');
      itemWrap.className = 'chat-history-item-wrap';

      const item = document.createElement('div');
      item.className = `nav-item ${c.id === this.currentConversationId ? 'active' : ''}`;
      item.innerHTML = `
        <svg class="chat-item-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="flex-shrink:0;"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
        <span class="chat-history-title">${this.escapeHtml(c.title)}</span>
        <button class="chat-history-menu-btn" title="Options">⋮</button>
      `;

      item.addEventListener('click', (e) => {
        if (!e.target.closest('.chat-history-menu-btn')) {
          this.selectConversation(c.id);
        }
      });

      const menuBtn = item.querySelector('.chat-history-menu-btn');
      if (menuBtn) {
        menuBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          this.toggleConversationMenu(itemWrap, c.id, c.title);
        });
      }

      itemWrap.appendChild(item);
      listEl.appendChild(itemWrap);
    });
  },

  toggleConversationMenu(parentEl, convId, currentTitle) {
    document.querySelectorAll('.chat-item-dropdown-menu').forEach(m => m.remove());

    const menu = document.createElement('div');
    menu.className = 'chat-item-dropdown-menu';
    menu.innerHTML = `
      <button class="chat-dropdown-action btn-rename-action">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
        <span>Rename</span>
      </button>
      <button class="chat-dropdown-action btn-delete-action" style="color:var(--danger, #EF4444);">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/></svg>
        <span>Delete</span>
      </button>
    `;

    menu.querySelector('.btn-rename-action').addEventListener('click', (e) => {
      e.stopPropagation();
      menu.remove();
      this.renameConversation(convId, currentTitle);
    });

    menu.querySelector('.btn-delete-action').addEventListener('click', (e) => {
      e.stopPropagation();
      menu.remove();
      this.deleteConversation(convId);
    });

    parentEl.appendChild(menu);

    const closeHandler = (e) => {
      if (!menu.contains(e.target) && e.target !== parentEl.querySelector('.chat-history-menu-btn')) {
        menu.remove();
        document.removeEventListener('click', closeHandler);
      }
    };
    setTimeout(() => document.addEventListener('click', closeHandler), 50);
  },

  renameConversation(convId, currentTitle) {
    App.showConfirmCard({
      icon: `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="var(--btn-peacock-blue)" stroke-width="2.2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>`,
      title: "Rename Conversation",
      desc: "Enter a new title for this conversation:",
      hasInput: true,
      defaultValue: currentTitle,
      inputPlaceholder: "New conversation title",
      confirmText: "Save Title",
      onConfirm: async (newTitle) => {
        if (!newTitle || newTitle.trim() === '') return;
        try {
          await fetch(`/api/conversations/${convId}`, {
            method: 'PATCH',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${AuthModule.token}`
            },
            body: JSON.stringify({ title: newTitle.trim() })
          });
          this.loadConversations();
        } catch (e) {}
      }
    });
  },

  deleteConversation(convId) {
    App.showConfirmCard({
      icon: `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#EF4444" stroke-width="2.2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/></svg>`,
      title: "Delete Conversation",
      desc: "Are you sure you want to delete this conversation? This action cannot be undone.",
      confirmText: "Delete",
      isDanger: true,
      onConfirm: async () => {
        try {
          await fetch(`/api/conversations/${convId}`, {
            method: 'DELETE',
            headers: { 'Authorization': `Bearer ${AuthModule.token}` }
          });
          if (this.currentConversationId === convId) {
            this.currentConversationId = null;
          }
          this.loadConversations();
        } catch (e) {}
      }
    });
  },

  async startNewConversation() {
    if (!AuthModule.token) return;
    try {
      const res = await fetch('/api/conversations', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${AuthModule.token}`
        },
        body: JSON.stringify({ title: 'New Conversation', model_id: this.activeModelId })
      });
      if (!res.ok) return;

      const newConv = await res.json();
      this.currentConversationId = newConv.id;
      this.loadConversations();
      this.clearMessagesContainer();
    } catch (e) {}
  },

  async selectConversation(convId) {
    if (!AuthModule.token) return;
    this.currentConversationId = convId;
    try {
      const res = await fetch(`/api/conversations/${convId}`, {
        headers: { 'Authorization': `Bearer ${AuthModule.token}` }
      });
      if (!res.ok) return;

      const conv = await res.json();
      this.activeModelId = conv.model_id || 'peacock_ultra';
      ModelsModule.selectModel(this.activeModelId, false);

      this.renderMessages(conv.messages || []);
      this.loadConversations();
    } catch (e) {}
  },

  clearMessagesContainer() {
    const container = document.getElementById('messages-container');
    if (!container) return;

    container.innerHTML = `
      <div class="empty-chat-hero">
        <div class="empty-chat-emblem-wrap">
          <div class="empty-chat-aura"></div>
          <img src="/static/images/logo.png" alt="PEACOCK AI Logo" class="empty-chat-logo">
        </div>
        <h2 class="empty-chat-title">How can I help you today?</h2>
      </div>
    `;
  },

  renderMessages(messages) {
    const container = document.getElementById('messages-container');
    if (!container) return;

    if (messages.length === 0) {
      this.clearMessagesContainer();
      return;
    }

    container.innerHTML = '';
    messages.forEach(m => {
      this.appendMessageBubble(m.role, m.content, m.id, m.model_id, m.feedback, m.file_attachments);
    });
    this.scrollToBottom();
  },

  appendMessageBubble(role, content, msgId = null, modelId = null, feedback = null, attachments = []) {
    const container = document.getElementById('messages-container');
    if (!container) return null;

    const hero = container.querySelector('.empty-chat-hero');
    if (hero) hero.remove();

    const row = document.createElement('div');
    row.className = `message-row ${role}`;
    if (msgId) row.id = `msg-${msgId}`;

    const isAssistant = role === 'assistant';

    let attachmentHtml = '';
    if (attachments && attachments.length > 0) {
      attachmentHtml = `<div class="msg-attachments-section">` + attachments.map(a => {
        const iconSvg = UploadModule.getFileIconSvg(a.filename, a.file_type, a.extracted_text);
        const sizeStr = UploadModule.formatFileSize(a.file_size);
        const extStr = (a.filename || '').split('.').pop().toUpperCase();
        return `
          <div class="attachment-file-card readonly">
            <div class="attachment-card-icon-wrap">${iconSvg}</div>
            <div class="attachment-card-info">
              <span class="attachment-card-filename" title="${this.escapeHtml(a.filename || 'Attached File')}">${this.escapeHtml(a.filename || 'Attached File')}</span>
              <span class="attachment-card-meta">${extStr} • ${sizeStr}</span>
            </div>
          </div>
        `;
      }).join('') + `</div>`;
    }

    const formattedContent = isAssistant ? this.parseMarkdown(content) : this.escapeHtml(content).replace(/\n/g, '<br>');

    const actionsHtml = isAssistant ? `
      <div class="message-actions-bar">
        <button class="msg-action-btn btn-copy-msg" title="Copy message"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg></button>
      </div>
    ` : '';

    row.innerHTML = `
      <div class="message-bubble-wrap">
        ${attachmentHtml}
        <div class="message-bubble">${formattedContent}</div>
        ${actionsHtml}
      </div>
    `;

    const copyBtn = row.querySelector('.btn-copy-msg');
    if (copyBtn) {
      copyBtn.addEventListener('click', () => {
        const bubble = row.querySelector('.message-bubble');
        const textToCopy = bubble ? bubble.innerText : content;
        navigator.clipboard.writeText(textToCopy);
        copyBtn.style.color = '#10B981';
        setTimeout(() => copyBtn.style.color = '', 1500);
      });
    }

    container.appendChild(row);
    this.scrollToBottom();
    return row;
  },

  async sendMessage() {
    if (this.isGenerating) return;

    const inputEl = document.getElementById('composer-textarea');
    const prompt = inputEl ? inputEl.value.trim() : '';
    const attachments = UploadModule.getPendingAttachments();

    if (!prompt && attachments.length === 0) return;

    // IF USER IS NOT LOGGED IN / NO ACCOUNT: Require Auth before starting conversation!
    if (!AuthModule.token || !AuthModule.currentUser) {
      this.pendingPrompt = prompt;
      const modal = document.getElementById('auth-modal-overlay');
      const errorEl = document.getElementById('auth-error-msg');
      if (errorEl) {
        errorEl.textContent = "Please sign in or create an account to start chatting with PEACOCK AI.";
        errorEl.style.display = 'block';
      }
      if (modal) modal.classList.add('active');
      return;
    }

    if (!this.currentConversationId) {
      await this.startNewConversation();
    }

    inputEl.value = '';
    UploadModule.clearAttachments();

    this.appendMessageBubble('user', prompt, null, null, null, attachments);

    this.isGenerating = true;

    const typingIndicator = this.showTypingIndicator();

    const streamingEnabled = SettingsModule.settings.streaming_enabled ?? true;

    if (streamingEnabled) {
      await this.handleStreamingChat(prompt, attachments, typingIndicator);
    } else {
      await this.handleStandardChat(prompt, attachments, typingIndicator);
    }

    this.isGenerating = false;
  },

  async handleStreamingChat(prompt, attachments, typingIndicator) {
    const attachmentsJson = encodeURIComponent(JSON.stringify(attachments));
    const url = `/api/chat/stream?conversation_id=${this.currentConversationId}&prompt=${encodeURIComponent(prompt)}&model_id=${this.activeModelId}&file_attachments_json=${attachmentsJson}`;

    let assistantRow = null;
    let bubbleEl = null;
    let fullText = '';

    const eventSource = new EventSource(url);

    eventSource.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);

        if (data.type === 'start') {
          if (typingIndicator) typingIndicator.remove();
          assistantRow = this.appendMessageBubble('assistant', '', data.message_id, data.model_id);
          if (assistantRow) {
            bubbleEl = assistantRow.querySelector('.message-bubble');
          }
        } else if (data.type === 'chunk') {
          fullText += data.text;
          if (!assistantRow) {
            if (typingIndicator) typingIndicator.remove();
            assistantRow = this.appendMessageBubble('assistant', '', null, null);
          }
          if (!bubbleEl && assistantRow) {
            bubbleEl = assistantRow.querySelector('.message-bubble');
          }
          if (bubbleEl) {
            bubbleEl.innerHTML = this.parseMarkdown(fullText);
            this.scrollToBottom();
          }
        } else if (data.type === 'end') {
          eventSource.close();
          this.loadConversations();
        } else if (data.type === 'error') {
          eventSource.close();
          if (typingIndicator) typingIndicator.remove();
          this.appendMessageBubble('assistant', `⚠️ **Error**: ${data.error}`);
        }
      } catch (e) {}
    };

    eventSource.onerror = () => {
      eventSource.close();
      if (typingIndicator) typingIndicator.remove();
      this.isGenerating = false;
    };
  },

  async handleStandardChat(prompt, attachments, typingIndicator) {
    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${AuthModule.token}`
        },
        body: JSON.stringify({
          conversation_id: this.currentConversationId,
          content: prompt,
          model_id: this.activeModelId,
          file_attachments: attachments
        })
      });

      if (typingIndicator) typingIndicator.remove();

      if (res.ok) {
        const msg = await res.json();
        this.appendMessageBubble('assistant', msg.content, msg.id, msg.model_id);
        this.loadConversations();
      } else {
        const err = await res.json();
        this.appendMessageBubble('assistant', `⚠️ **Error**: ${err.detail || 'Failed to generate response'}`);
      }
    } catch (e) {
      if (typingIndicator) typingIndicator.remove();
    }
  },

  showTypingIndicator() {
    const container = document.getElementById('messages-container');
    if (!container) return null;

    const row = document.createElement('div');
    row.className = 'message-row assistant typing-row';
    row.innerHTML = `
      <div class="message-bubble-wrap">
        <div class="typing-indicator">
          <div class="typing-dot"></div>
          <div class="typing-dot"></div>
          <div class="typing-dot"></div>
        </div>
      </div>
    `;
    container.appendChild(row);
    this.scrollToBottom();
    return row;
  },

  scrollToBottom() {
    const container = document.getElementById('messages-container');
    if (container) {
      container.scrollTop = container.scrollHeight;
    }
  },

  parseMarkdown(text) {
    if (!text) return '';

    let html = text.replace(/```(\w+)?\n([\s\S]*?)```/g, (match, lang, code) => {
      const language = lang || 'code';
      const escapedCode = this.escapeHtml(code.trim());
      return `
        <pre><div class="code-block-header"><span>${language}</span><button class="btn-copy-code" onclick="navigator.clipboard.writeText(this.parentElement.nextElementSibling.innerText)">Copy</button></div><code>${escapedCode}</code></pre>
      `;
    });

    html = html.replace(/!\[(.*?)\]\((.*?)\)/g, (match, alt, url) => {
      const cleanUrl = url.trim();
      return `<div class="chat-image-wrap"><img src="${this.escapeHtml(cleanUrl)}" alt="${this.escapeHtml(alt)}" class="chat-inline-image" loading="lazy" onclick="window.open(this.src, '_blank')"></div>`;
    });

    html = html.replace(/`([^`]+)`/g, (match, code) => `<code>${this.escapeHtml(code)}</code>`);
    html = html.replace(/^### (.*$)/gim, '<h3>$1</h3>');
    html = html.replace(/^## (.*$)/gim, '<h2>$1</h2>');
    html = html.replace(/^# (.*$)/gim, '<h1>$1</h1>');
    html = html.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
    html = html.replace(/\*(.*?)\*/g, '<em>$1</em>');
    html = html.replace(/^\> (.*$)/gim, '<blockquote>$1</blockquote>');
    html = html.replace(/\n\n/g, '<br><br>');

    return html;
  },

  escapeHtml(str) {
    return (str || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }
};
