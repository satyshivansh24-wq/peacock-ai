/* PEACOCK AI — 15 Peacock Color System & Dynamic Model Selector */

const PEACOCK_COLORS = [
  '#0F4C81', // 01 Deep Peacock Blue
  '#1E40AF', // 02 Electric Blue
  '#06B6D4', // 03 Cyan
  '#14B8A6', // 04 Turquoise
  '#0D9488', // 05 Teal
  '#10B981', // 06 Emerald
  '#22C55E', // 07 Green
  '#84CC16', // 08 Lime
  '#EAB308', // 09 Gold
  '#FACC15', // 10 Yellow
  '#F97316', // 11 Orange
  '#FF6B6B', // 12 Coral
  '#EC4899', // 13 Pink
  '#A855F7', // 14 Purple
  '#6366F1'  // 15 Indigo
];

const ModelsModule = {
  models: [],
  activeModel: null,

  async init() {
    await this.loadModels();
    this.bindEvents();
  },

  bindEvents() {
    const pill = document.getElementById('model-selector-pill');
    const modal = document.getElementById('models-modal-overlay');
    const closeBtn = document.getElementById('btn-close-models-modal');

    if (pill && modal) {
      pill.addEventListener('click', () => {
        modal.classList.add('active');
      });
    }

    if (closeBtn && modal) {
      closeBtn.addEventListener('click', () => {
        modal.classList.remove('active');
      });
    }
  },

  async loadModels() {
    try {
      const res = await fetch('/api/models');
      if (!res.ok) return;

      const rawModels = await res.json();
      
      // Assign exact 15 Peacock Colors
      this.models = rawModels.map((m, index) => {
        const hex = PEACOCK_COLORS[index % PEACOCK_COLORS.length];
        return {
          ...m,
          color_hex: hex
        };
      });

      this.renderModelGrid();
      
      if (this.models.length > 0 && !this.activeModel) {
        this.selectModel('peacock_ultra', false);
      }
    } catch (e) {}
  },

  renderModelGrid() {
    const grid = document.getElementById('models-grid-container');
    if (!grid) return;

    grid.innerHTML = '';

    this.models.forEach((m, index) => {
      const card = document.createElement('div');
      const hex = m.color_hex;
      card.className = `model-card-saas ${this.activeModel && this.activeModel.id === m.id ? 'active' : ''}`;
      card.style.setProperty('--card-color', hex);
      card.style.setProperty('--card-glow', `${hex}40`);

      const tagsHtml = m.capabilities.map(c => `<span class="capability-pill">${c}</span>`).join('');

      card.innerHTML = `
        <div class="model-card-top">
          <div class="model-card-icon-wrap">${this.getIconSvg(m.icon)}</div>
          <span style="font-size:0.7rem; font-weight:800; color:${hex}; border:1px solid ${hex}40; padding:2px 8px; border-radius:12px;">MODEL 0${index + 1}</span>
        </div>
        <div class="model-card-title-text">${m.name}</div>
        <div class="model-card-provider-text">${m.provider}</div>
        <div class="model-card-desc-text">${m.description}</div>
        <div class="model-card-tags-row">${tagsHtml}</div>
      `;

      card.addEventListener('click', () => {
        this.selectModel(m.id);
        const modal = document.getElementById('models-modal-overlay');
        if (modal) modal.classList.remove('active');
      });

      grid.appendChild(card);
    });
  },

  selectModel(modelId, updateChatConv = true) {
    const model = this.models.find(m => m.id === modelId) || this.models[0];
    if (!model) return;

    this.activeModel = model;
    ChatModule.activeModelId = model.id;

    // Dynamically update CSS variables across entire document root
    const root = document.documentElement;
    const hex = model.color_hex;
    root.style.setProperty('--ai-accent', hex);
    root.style.setProperty('--ai-accent-glow', `${hex}50`);
    root.style.setProperty('--ai-accent-soft', `${hex}18`);
    root.style.setProperty('--ai-gradient', `linear-gradient(135deg, ${hex}, #A855F7)`);

    // Update Top Navbar Pill
    const pillName = document.getElementById('current-model-name');
    const pillColor = document.getElementById('current-model-color-indicator');

    if (pillName) pillName.textContent = model.name;
    if (pillColor) {
      pillColor.style.backgroundColor = hex;
      pillColor.style.boxShadow = `0 0 12px ${hex}`;
    }

    this.renderModelGrid();

    if (updateChatConv && ChatModule.currentConversationId) {
      fetch(`/api/conversations/${ChatModule.currentConversationId}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${AuthModule.token}`
        },
        body: JSON.stringify({ model_id: model.id })
      });
    }
  },

  getIconSvg(iconName) {
    const icons = {
      feather: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.24 12.24a6 6 0 0 0-8.49-8.49L3 13v5h5l9.24-9.24z"/></svg>`,
      cpu: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="4" y="4" width="16" height="16" rx="2"/><rect x="9" y="9" width="6" height="6"/></svg>`,
      code: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>`,
      zap: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>`,
      compass: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polygon points="16.24 7.76 14.12 14.12 7.76 16.24 9.88 9.88 16.24 7.76"/></svg>`,
      shield: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>`,
      globe: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/></svg>`,
      layers: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="12 2 2 7 12 12 22 7 12 2"/></svg>`,
      search: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>`
    };
    return icons[iconName] || icons.feather;
  }
};
