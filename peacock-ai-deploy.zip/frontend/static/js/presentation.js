/* PEACOCK AI — College Presentation & Architecture Module */

const PresentationModule = {
  init() {
    this.bindEvents();
  },

  bindEvents() {
    const btn = document.getElementById('btn-open-presentation');
    const modal = document.getElementById('presentation-modal-overlay');
    const closeBtn = document.getElementById('btn-close-presentation-modal');

    if (btn && modal) {
      btn.addEventListener('click', () => {
        modal.classList.add('active');
        this.loadAboutInfo();
      });
    }

    if (closeBtn && modal) {
      closeBtn.addEventListener('click', () => {
        modal.classList.remove('active');
      });
    }
  },

  async loadAboutInfo() {
    try {
      const res = await fetch('/api/presentation/about');
      if (!res.ok) return;

      const data = await res.json();
      this.renderArchitectureFlow(data.architecture_flow || []);
      this.renderColorConcept(data.colors || []);
    } catch (e) {}
  },

  renderArchitectureFlow(steps) {
    const container = document.getElementById('architecture-flowchart-container');
    if (!container) return;

    container.innerHTML = steps.map(s => `
      <div class="arch-node">
        <div class="arch-node-number">${s.step}</div>
        <div class="arch-node-content">
          <h4>${s.name}</h4>
          <p>${s.desc}</p>
        </div>
      </div>
    `).join('');
  },

  renderColorConcept(colors) {
    const container = document.getElementById('color-concept-container');
    if (!container) return;

    container.innerHTML = colors.map(c => `
      <div class="color-concept-card">
        <div class="color-swatch" style="background:${c.hex};box-shadow:0 0 10px ${c.hex}60;"></div>
        <div style="font-size:0.78rem;font-weight:700;">${c.model}</div>
        <div style="font-size:0.7rem;color:var(--text-dim);">${c.name}</div>
      </div>
    `).join('');
  }
};
