/* PEACOCK AI — Settings & Provider Status Module */

const SettingsModule = {
  settings: {
    theme: 'dark',
    default_model: 'peacock_ultra',
    response_language: 'Auto (Match Prompt)',
    enter_to_send: true,
    streaming_enabled: true
  },

  async init() {
    this.bindEvents();
    if (AuthModule.token) {
      await this.loadUserSettings();
    }
  },

  bindEvents() {
    const btn = document.getElementById('btn-open-settings');
    const modal = document.getElementById('settings-modal-overlay');
    const closeBtn = document.getElementById('btn-close-settings-modal');

    if (btn && modal) {
      btn.addEventListener('click', () => {
        modal.classList.add('active');
        this.loadProviderStatuses();
      });
    }

    if (closeBtn && modal) {
      closeBtn.addEventListener('click', () => {
        modal.classList.remove('active');
      });
    }

    // Settings Toggle Listeners
    const enterToggle = document.getElementById('toggle-enter-send');
    const streamToggle = document.getElementById('toggle-streaming');

    if (enterToggle) {
      enterToggle.addEventListener('change', (e) => {
        this.settings.enter_to_send = e.target.checked;
        this.saveSettings();
      });
    }

    if (streamToggle) {
      streamToggle.addEventListener('change', (e) => {
        this.settings.streaming_enabled = e.target.checked;
        this.saveSettings();
      });
    }
  },

  async loadUserSettings() {
    try {
      const res = await fetch('/api/settings', {
        headers: { 'Authorization': `Bearer ${AuthModule.token}` }
      });
      if (!res.ok) return;

      this.settings = await res.json();
      
      const enterToggle = document.getElementById('toggle-enter-send');
      const streamToggle = document.getElementById('toggle-streaming');

      if (enterToggle) enterToggle.checked = this.settings.enter_to_send;
      if (streamToggle) streamToggle.checked = this.settings.streaming_enabled;
    } catch (e) {}
  },

  async saveSettings() {
    try {
      await fetch('/api/settings', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${AuthModule.token}`
        },
        body: JSON.stringify(this.settings)
      });
    } catch (e) {}
  },

  async loadProviderStatuses() {
    try {
      const res = await fetch('/api/models/statuses');
      if (!res.ok) return;

      const statuses = await res.json();
      const container = document.getElementById('provider-statuses-table-body');
      if (!container) return;

      container.innerHTML = statuses.map(s => `
        <tr>
          <td><span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:${s.color_hex};margin-right:8px;"></span><strong>${s.name}</strong></td>
          <td><span class="badge ${s.status.includes('CONNECTED') ? 'badge-live' : 'badge-demo'}">${s.status}</span></td>
          <td>${s.capabilities.join(', ')}</td>
        </tr>
      `).join('');
    } catch (e) {}
  }
};
