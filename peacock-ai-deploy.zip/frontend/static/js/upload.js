/* PEACOCK AI — Professional File & Image Attachment Module */

const UploadModule = {
  pendingAttachments: [],

  init() {
    this.bindEvents();
  },

  bindEvents() {
    const attachBtn = document.getElementById('btn-attach-file');
    const fileInput = document.getElementById('composer-file-input');

    if (attachBtn && fileInput) {
      attachBtn.addEventListener('click', () => fileInput.click());
      fileInput.addEventListener('change', (e) => this.handleFileSelect(e));
    }
  },

  async handleFileSelect(e) {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    for (let file of files) {
      if (!AuthModule.token) {
        await this.processClientFile(file);
        continue;
      }

      const formData = new FormData();
      formData.append('file', file);
      if (ChatModule.currentConversationId) {
        formData.append('conversation_id', ChatModule.currentConversationId);
      }

      try {
        const res = await fetch('/api/files/upload', {
          method: 'POST',
          headers: { 'Authorization': `Bearer ${AuthModule.token}` },
          body: formData
        });

        if (res.ok) {
          const fileData = await res.json();
          this.pendingAttachments.push(fileData);
          this.renderAttachmentCards();
        } else {
          await this.processClientFile(file);
        }
      } catch (err) {
        await this.processClientFile(file);
      }
    }

    e.target.value = '';
  },

  async processClientFile(file) {
    return new Promise((resolve) => {
      const reader = new FileReader();
      const ext = (file.name || '').split('.').pop().toLowerCase();
      const isImage = ['png', 'jpg', 'jpeg', 'webp', 'gif', 'svg'].includes(ext);

      if (isImage) {
        reader.readAsDataURL(file);
        reader.onload = (evt) => {
          this.pendingAttachments.push({
            id: 'client_' + Date.now() + Math.random().toString(36).substring(2, 6),
            filename: file.name,
            file_type: 'image',
            file_size: file.size,
            extracted_text: evt.target.result
          });
          this.renderAttachmentCards();
          resolve();
        };
        reader.onerror = () => {
          resolve();
        };
      } else {
        reader.readAsText(file);
        reader.onload = (evt) => {
          this.pendingAttachments.push({
            id: 'client_' + Date.now() + Math.random().toString(36).substring(2, 6),
            filename: file.name,
            file_type: 'document',
            file_size: file.size,
            extracted_text: evt.target.result ? evt.target.result.substring(0, 25000) : `[Document Attached: ${file.name}]`
          });
          this.renderAttachmentCards();
          resolve();
        };
        reader.onerror = () => {
          this.pendingAttachments.push({
            id: 'client_' + Date.now() + Math.random().toString(36).substring(2, 6),
            filename: file.name,
            file_type: 'document',
            file_size: file.size,
            extracted_text: `[Document Attached: ${file.name}]`
          });
          this.renderAttachmentCards();
          resolve();
        };
      }
    });
  },

  renderAttachmentCards() {
    const container = document.getElementById('attachments-preview-bar');
    if (!container) return;

    container.innerHTML = '';

    this.pendingAttachments.forEach((a, index) => {
      const card = document.createElement('div');
      card.className = 'attachment-file-card';

      const iconSvg = this.getFileIconSvg(a.filename, a.file_type, a.extracted_text);
      const sizeStr = this.formatFileSize(a.file_size);
      const extStr = (a.filename || '').split('.').pop().toUpperCase();

      card.innerHTML = `
        <div class="attachment-card-icon-wrap">${iconSvg}</div>
        <div class="attachment-card-info">
          <span class="attachment-card-filename" title="${this.escapeHtml(a.filename)}">${this.escapeHtml(a.filename)}</span>
          <span class="attachment-card-meta">${extStr} • ${sizeStr}</span>
        </div>
        <button type="button" class="btn-remove-attachment-card" title="Remove File">✕</button>
      `;

      card.querySelector('.btn-remove-attachment-card').addEventListener('click', () => {
        this.pendingAttachments.splice(index, 1);
        this.renderAttachmentCards();
      });

      container.appendChild(card);
    });
  },

  getFileIconSvg(filename, fileType, extractedText) {
    const ext = (filename || '').split('.').pop().toLowerCase();

    if (fileType === 'image' || ['png', 'jpg', 'jpeg', 'webp', 'gif', 'svg'].includes(ext)) {
      if (extractedText && extractedText.startsWith('data:image')) {
        return `<img src="${extractedText}" class="attachment-card-thumb" alt="Preview">`;
      }
      return `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#EC4899" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>`;
    }

    if (ext === 'pdf') {
      return `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#EF4444" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>`;
    }

    if (ext === 'docx' || ext === 'doc') {
      return `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#2563EB" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>`;
    }

    if (ext === 'xlsx' || ext === 'csv') {
      return `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#10B981" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="8" y1="13" x2="16" y2="13"/><line x1="8" y1="17" x2="16" y2="17"/><line x1="12" y1="13" x2="12" y2="17"/></svg>`;
    }

    return `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#06B6D4" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><polyline points="10 13 8 15 10 17"/><polyline points="14 13 16 15 14 17"/></svg>`;
  },

  formatFileSize(bytes) {
    if (!bytes) return 'File';
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  },

  getPendingAttachments() {
    return [...this.pendingAttachments];
  },

  clearAttachments() {
    this.pendingAttachments = [];
    this.renderAttachmentCards();
  },

  escapeHtml(str) {
    return (str || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }
};
