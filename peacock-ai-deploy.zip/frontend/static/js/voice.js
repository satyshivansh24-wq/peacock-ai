/* PEACOCK AI — Speech Recognition & Voice Typing Module */

const VoiceModule = {
  recognition: null,
  isListening: false,

  init() {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) return;

    this.recognition = new SpeechRecognition();
    this.recognition.continuous = false;
    this.recognition.interimResults = true;

    this.recognition.onstart = () => {
      this.isListening = true;
      this.updateBtnUI(true);
    };

    this.recognition.onend = () => {
      this.isListening = false;
      this.updateBtnUI(false);
    };

    this.recognition.onresult = (event) => {
      const transcript = Array.from(event.results)
        .map(result => result[0])
        .map(result => result.transcript)
        .join('');

      const inputEl = document.getElementById('composer-textarea');
      if (inputEl) {
        inputEl.value = transcript;
      }
    };

    this.bindEvents();
  },

  bindEvents() {
    const voiceBtn = document.getElementById('btn-voice-input');
    if (voiceBtn) {
      voiceBtn.addEventListener('click', () => this.toggleVoiceInput());
    }
  },

  toggleVoiceInput() {
    if (!this.recognition) {
      alert("Speech recognition is not supported in your current browser.");
      return;
    }

    if (this.isListening) {
      this.recognition.stop();
    } else {
      this.recognition.start();
    }
  },

  updateBtnUI(listening) {
    const voiceBtn = document.getElementById('btn-voice-input');
    if (!voiceBtn) return;

    if (listening) {
      voiceBtn.classList.add('listening');
      voiceBtn.style.color = '#EF4444';
    } else {
      voiceBtn.classList.remove('listening');
      voiceBtn.style.color = '';
    }
  }
};
