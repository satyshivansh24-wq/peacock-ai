import pytest
import pytest_asyncio
import asyncio
from httpx import AsyncClient, ASGITransport
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from backend.main import app
from backend.database import Base, get_db
from backend.providers.provider_manager import provider_manager

test_engine = create_async_engine("sqlite+aiosqlite:///:memory:", echo=False, connect_args={"check_same_thread": False})
TestSessionLocal = async_sessionmaker(bind=test_engine, class_=AsyncSession, expire_on_commit=False)

async def override_get_db():
    async with TestSessionLocal() as session:
        yield session

app.dependency_overrides[get_db] = override_get_db

@pytest_asyncio.fixture(autouse=True)
async def setup_db():
    async with test_engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield
    async with test_engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)

@pytest.mark.asyncio
async def test_provider_manager_models():
    models = provider_manager.get_all_models()
    assert len(models) == 15
    model_ids = [m.id for m in models]
    assert "peacock_ultra" in model_ids
    assert "gpt4o_mind" in model_ids
    assert "deepseek_r1" in model_ids
    assert "peacock_demo" in model_ids

@pytest.mark.asyncio
async def test_auth_registration_and_login():
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        # Register
        reg_res = await ac.post("/api/auth/register", json={
            "full_name": "Test Peacock User",
            "email": "testuser@peacock.ai",
            "password": "peacockpassword123"
        })
        assert reg_res.status_code == 200, reg_res.text
        token_data = reg_res.json()
        assert "access_token" in token_data
        token = token_data["access_token"]

        # Login
        login_res = await ac.post("/api/auth/login", json={
            "email": "testuser@peacock.ai",
            "password": "peacockpassword123"
        })
        assert login_res.status_code == 200

        # Me endpoint
        me_res = await ac.get("/api/auth/me", headers={"Authorization": f"Bearer {token}"})
        assert me_res.status_code == 200
        assert me_res.json()["email"] == "testuser@peacock.ai"

@pytest.mark.asyncio
async def test_forgot_and_reset_password_flow():
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        # Register User
        await ac.post("/api/auth/register", json={
            "full_name": "Forgot User",
            "email": "forgot@peacock.ai",
            "password": "oldpassword123"
        })

        # Request OTP
        forgot_res = await ac.post("/api/auth/forgot-password", json={"email": "forgot@peacock.ai"})
        assert forgot_res.status_code == 200
        assert "otp_code" not in forgot_res.json()  # SECURE: OTP not exposed in API response

        from backend.api.auth import RESET_OTP_CACHE
        otp = RESET_OTP_CACHE.get("forgot@peacock.ai")

        # Reset Password
        reset_res = await ac.post("/api/auth/reset-password", json={
            "email": "forgot@peacock.ai",
            "otp_code": otp,
            "new_password": "newpassword456"
        })
        assert reset_res.status_code == 200
        assert "access_token" in reset_res.json()

        # Login with new password
        login_res = await ac.post("/api/auth/login", json={
            "email": "forgot@peacock.ai",
            "password": "newpassword456"
        })
        assert login_res.status_code == 200

@pytest.mark.asyncio
async def test_conversation_and_chat_flow():
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        # Register
        reg_res = await ac.post("/api/auth/register", json={
            "full_name": "Chat Tester",
            "email": "chattester@peacock.ai",
            "password": "peacockpassword123"
        })
        assert reg_res.status_code == 200, reg_res.text
        token = reg_res.json()["access_token"]
        headers = {"Authorization": f"Bearer {token}"}

        # Create Conversation
        conv_res = await ac.post("/api/conversations", json={"title": "Test Peacock Chat", "model_id": "peacock_ultra"}, headers=headers)
        assert conv_res.status_code == 200, conv_res.text
        conv_id = conv_res.json()["id"]

        # Send Message
        msg_res = await ac.post("/api/chat", json={
            "conversation_id": conv_id,
            "content": "Hello Peacock AI! Tell me about your 15 colors.",
            "model_id": "peacock_ultra"
        }, headers=headers)
        assert msg_res.status_code == 200, msg_res.text
        msg_data = msg_res.json()
        assert msg_data["role"] == "assistant"
        assert len(msg_data["content"]) > 0

@pytest.mark.asyncio
async def test_college_presentation_endpoint():
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        res = await ac.get("/api/presentation/about")
        assert res.status_code == 200
        data = res.json()
        assert data["title"] == "PEACOCK AI"
        assert len(data["colors"]) == 15
